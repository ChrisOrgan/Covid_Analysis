# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(phytools)


# Read and prepare tree ----
tree <- read.nexus(file = "nextstrain_groups_blab_sars-like-cov_tree_v3.nex")
tree$tip.label <- sQuote(tree$tip.label)

# Remove non-bat taxa ----
out <- sQuote(c("GZ0401", "A001", "USA/IL1/2020", "pangolin/Guangxi/P5L/2017",
                "pangolin/Guangdong/P2S/2019"))
tree_edit <- drop.tip(phy = tree, tip = out)
## tree_edit
## 
## Phylogenetic tree with 21 tips and 20 internal nodes.
## 
## Tip labels:
##   'As6526', 'bat/Yunnan/RaTG13/2013', 'bat/Yunnan/RmYN01/2019', 'bat/Yunnan/RmYN02/2019', 'bat_SL_CoVZC45', 'bat_SL_CoVZXC21', ...
## 
## Rooted; includes branch lengths.

# Write trees in the NEXUS format ----
writeNexus(
  tree = tree_edit,
  file = "nextstrain_groups_blab_sars-like-cov_tree_v3_bats.nex"
)
