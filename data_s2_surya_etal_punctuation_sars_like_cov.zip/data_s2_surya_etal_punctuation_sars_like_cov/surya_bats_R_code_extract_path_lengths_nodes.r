# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(phytools)


# Read tree ----
tree <- read.nexus(
  file = "nextstrain_groups_blab_sars-like-cov_tree_v3_bats.nex"
)

# Decompose the tree into a variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Extract path lengths (diagonals of the matrix) ----
path <- diag(vcv)

# Extract nodes ----
node <- NULL
for (genome in 1:length(tree$tip.label)) {
  node[genome] <- length(
    nodepath(
      phy = tree,
      from = length(tree$tip.label) + 1,  # root
      to = genome
    )
  ) - 2  # minus the root and terminal tip
}

# Create data frames ----
dat <- data.frame(sQuote(tree$tip.label), path, node)
dat_int <- data.frame(sQuote(tree$tip.label), path)

# Write data frame to a tab-delimited text file ----
write.table(
  dat,
  file = "surya_bats_R_data_path_lengths_nodes.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
write.table(
  dat_int,
  file = "surya_bats_R_data_path_lengths.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
