# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(phytools)


# Read tree ----
tree <- read.newick(file = "nextstrain_groups_blab_sars-like-cov_tree_v2.nwk")

# Enclose tip labels in single quotation marks ----
tree$tip.label <- gsub("'", "", tree$tip.label)
tree$tip.label <- sQuote(tree$tip.label)

# Pick one representative randomly from each cluster of similar genomes ----
## SARS-CoV-1 - Human
sars_cov1_h <- sQuote(c("TWS", "TWH", "Sino1_11", "Sin846", "Sin842", "Sin852",
                        "BJ01", "BJ04", "GZ0401", "GZ0402"))
set.seed(1)
sars_cov1_h_rep <- sample(sars_cov1_h, 1)
sars_cov1_h <- sars_cov1_h[!sars_cov1_h %in% sars_cov1_h_rep]
### sars_cov1_h_rep
### [1] "'GZ0401'"
## SARS-CoV-1 - Civet
sars_cov1_c <- sQuote(c("A001", "civet020", "PC4_227", "civet007"))
set.seed(2)
sars_cov1_c_rep <- sample(sars_cov1_c, 1)
sars_cov1_c <- sars_cov1_c[!sars_cov1_c %in% sars_cov1_c_rep]
### sars_cov1_c_rep
### [1] "'A001'"
## SARS-CoV-2
sars_cov2 <- sQuote(c("Japan/KY-V-029/2020", "Wuhan/WIV05/2019",
                      "Wuhan-Hu-1/2019", "Sweden/01/2020", "USA/IL1/2020",
                      "Nepal/61/2020", "USA/CA1/2020"))
set.seed(3)
sars_cov2_rep <- sample(sars_cov2, 1)
sars_cov2 <- sars_cov2[!sars_cov2 %in% sars_cov2_rep]
### sars_cov2_rep
## [1] "'USA/IL1/2020'"
## Pangolin - Guangxi
pangolin <- sQuote(c("pangolin/Guangxi/P2V/2017", "pangolin/Guangxi/P5E/2017",
                     "pangolin/Guangxi/P5L/2017", "pangolin/Guangxi/P4L/2017",
                     "pangolin/Guangxi/P3B/2017", "pangolin/Guangxi/P1E/2017"))
set.seed(4)
pangolin_rep <- sample(pangolin, 1)
pangolin <- pangolin[!pangolin %in% pangolin_rep]
### pangolin_rep
## [1] "'pangolin/Guangxi/P5L/2017'"
out <- c(sars_cov1_h, sars_cov1_c, sars_cov2, pangolin)
tree_edit <- drop.tip(phy = tree, tip = out)

# Write removed genomes to a text file ----
write.table(
  out,
  file = "surya_R_output_removed_genomes.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)

# Write trees in the NEXUS format ----
writeNexus(
  tree = tree,
  file = "nextstrain_groups_blab_sars-like-cov_tree_v2.nex"
)
writeNexus(
  tree = tree_edit,
  file = "nextstrain_groups_blab_sars-like-cov_tree_v3.nex"
)
