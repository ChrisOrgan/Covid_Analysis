# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
dat <- read.table("surya_bats_R_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")

# Plot scatter plots ----
plot_reg <-
  ggplot(dat, aes(node, path)) +
    geom_point() +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.134551575 + 0.001669835*min(dat$node),
      yend = 0.134551575 + 0.001669835*max(dat$node),
      color = "dark gray",
      size = 0.5
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (substitutions/site)\n")
plot_int <-
  ggplot(dat, aes(node, path)) +
    geom_point() +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.1386322,
      yend = 0.1386322,
      color = "dark gray",
      size = 0.5
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (substitutions/site)\n")

# Save scatter plots ----
CairoPDF("surya_bats_figure_punctuation_sars_like.pdf", width = 4.75,
         height = 4)
print(plot_reg)
graphics.off()
CairoSVG("surya_bats_figure_punctuation_sars_like.svg", width = 4.75,
         height = 4)
print(plot_reg)
graphics.off()
CairoPDF("surya_bats_figure_punctuation_sars_like_intercept.pdf", width = 4.75,
         height = 4)
print(plot_int)
graphics.off()
CairoSVG("surya_bats_figure_punctuation_sars_like_intercept.svg", width = 4.75,
         height = 4)
print(plot_int)
graphics.off()
