# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(Cairo)
library(ggimage)
library(ggtree)
library(phytools)
library(svglite)


# Read tree ----
tree <- read.nexus(file = "nextstrain_groups_blab_sars-like-cov_tree_v3.nex")

# Load and prepare data ----
dat <- read.table("surya_R_data_path_lengths_nodes.txt", sep = "\t")
## ggtree is very sensitive with colnames; don't change them!
meta <- read.delim(
  "nextstrain_groups_blab_sars-like-cov_metadata.tsv",
  header = TRUE,
  sep = "\t"
)
meta <- meta[match(dat$V1, meta$Strain), ]
dat$host <- meta$host

# Plot tree ----
plot_tree <-
  ggtree(tree, size = 0.35) %<+% dat +
    xlim(0, 0.35) +
    geom_tiplab(size = 2, offset = 0.005) +
    geom_tippoint(aes(color = host), size = 1.5) +
    theme_tree2(legend = "right", legend.title = element_blank()) +
    labs(caption = "substitutions/site")

# Save plot ----
CairoPDF("surya_figure_punctuation_sars_like_tree.pdf", width = 4.75, 
         height = 3)
print(plot_tree)
graphics.off()
CairoSVG("surya_figure_punctuation_sars_like_tree.svg", width = 4.75,
         height = 3)
print(plot_tree)
graphics.off()
