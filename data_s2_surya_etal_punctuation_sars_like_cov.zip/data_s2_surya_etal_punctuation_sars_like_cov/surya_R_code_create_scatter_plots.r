# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
dat <- read.table("surya_R_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
dat$genome <- as.character(dat$genome)
meta <- read.delim(
  "nextstrain_groups_blab_sars-like-cov_metadata.tsv",
  header = TRUE,
  sep = "\t"
)
out <- read.table("surya_R_output_removed_genomes.txt", sep = "\t")
colnames(out) <- c("removed")
out$removed <- as.character(out$removed)
dat_edit <- dat[!dat$genome %in% out$removed, ]
meta_edit <- meta[!meta$Strain %in% out$removed, ]
dat_edit <- dat_edit[match(meta_edit$Strain, dat_edit$genome), ]
dat_edit <- cbind(dat_edit, meta_edit$host)
colnames(dat_edit)[4] <- "host"

# Plot scatter plots ----
plot_reg <-
  ggplot(dat_edit, aes(node, path, color = host)) +
    geom_jitter(width = 0.2) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.134093506 + 0.002992163*min(dat$node),
      yend = 0.134093506 + 0.002992163*max(dat$node),
      color = "dark gray",
      size = 0.5
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (substitutions/site)\n")
plot_int <-
  ggplot(dat_edit, aes(node, path, color = host)) +
    geom_jitter(width = 0.2) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.1421708,
      yend = 0.1421708,
      color = "dark gray",
      size = 0.5
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (substitutions/site)\n")

# Save scatter plots ----
CairoPDF("surya_figure_punctuation_sars_like.pdf", width = 4.75, height = 4)
print(plot_reg)
graphics.off()
CairoSVG("surya_figure_punctuation_sars_like.svg", width = 4.75, height = 4)
print(plot_reg)
graphics.off()
CairoPDF("surya_figure_punctuation_sars_like_intercept.pdf", width = 4.75,
         height = 4)
print(plot_int)
graphics.off()
CairoSVG("surya_figure_punctuation_sars_like_intercept.svg", width = 4.75,
         height = 4)
print(plot_int)
graphics.off()
