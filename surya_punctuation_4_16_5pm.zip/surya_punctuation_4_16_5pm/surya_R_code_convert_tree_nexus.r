# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


library(phytools)  # v0.6.99


# Read tree ----
tree <- read.newick(file = "nextstrain_ncov_global_tree_v2.nwk")

# Write tree in the NEXUS format ----
writeNexus(
  tree = tree,
  file = "nextstrain_ncov_global_tree_v3.nex"
)
