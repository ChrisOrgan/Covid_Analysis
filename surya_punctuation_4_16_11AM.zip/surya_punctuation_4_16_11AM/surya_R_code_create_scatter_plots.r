# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


library(Cairo)  # v1.5.10
library(ggplot2)  # v3.2.1
library(ggthemes)  # v4.2.0
library(htmlwidgets)  # v1.5.1
library(plotly)  # v4.9.1
library(svglite)  # v1.2.2


# Load and prepare data ----
dat <- read.table("surya_BayesTraits_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
meta <- read.delim(
  "nextstrain_ncov_global_metadata.tsv",
  header = TRUE,
  sep = "\t"
)
dat <- cbind(dat, meta$Region)
colnames(dat)[4] <- "continent"

# Plot scatter plots ----
scatter_plot <-
  ggplot(dat, aes(node, path)) +
    geom_point(color = "gray") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 8.379945503580 + -0.062816160490*min(dat$node),
      yend = 8.379945503580 + -0.062816160490*max(dat$node),
      color = "black",
      size = 1
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(
      subtitle = "Total Path Lengths (mutations)\n",
      x = "\nNumber of Nodes",
      y = NULL
    )
scatter_plot_region <-
  ggplot(dat, aes(node, path, color = continent)) +
    geom_jitter(size = 0.75, height = 0.2, width = 0.2, alpha = 0.3) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(
      legend.direction = "vertical",
      legend.position = "right"
    ) +
    labs(
      subtitle = "Total Path Lengths (mutations)\n",
      x = "\nNumber of Nodes",
      y = NULL,
      color = NULL
    )
## Interactive plot
interactive_plot <-
  ggplot(dat, aes(node, path, color = continent, label = genome)) +
    geom_jitter(height = 0.25, width = 0.25, alpha = 0.4) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(legend.title = element_blank()) +
    labs(
      x = "Number of Nodes",
      y = "Total Path Lengths (mutations)"
    )
interactive_plot <- ggplotly(interactive_plot)

# Save scatter plots ----
CairoPDF("surya_figure_punctuation.pdf", width = 6.535, height = 4.039)
print(scatter_plot)
graphics.off()
CairoSVG("surya_figure_punctuation.svg", width = 6.535, height = 4.039)
print(scatter_plot)
graphics.off()
CairoPDF("surya_figure_punctuation_region.pdf", width = 6.535, height = 4.039)
print(scatter_plot_region)
graphics.off()
CairoSVG("surya_figure_punctuation_region.svg", width = 6.535, height = 4.039)
print(scatter_plot_region)
graphics.off()
## Interactive plot
saveWidget(
  widget = as_widget(interactive_plot),
  file = "surya_figure_punctuation_interactive.html"
)
