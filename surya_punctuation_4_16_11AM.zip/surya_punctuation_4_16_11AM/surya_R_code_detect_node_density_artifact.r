# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


library(ape)  # v5.3
library(nlme)  # v3.1-143


# Read tree ----
tree <- read.nexus(file = "nextstrain_ncov_global_tree_v4.nex")

# Load and prepare data ----
dat <- read.table("surya_BayesTraits_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
rownames(dat) <- dat$genome
dat <- dat[, -1]
dat$node <- dat$node + 1  # This addition prevents log-transforming zero below

# Define the variance-covariance matrix ----
vcv <- corPagel(1, tree)

# Detect the node-density artifact ----
pgls <- gls(log(path) ~ log(node), data = dat, correlation = vcv)
delta <- 1 / as.numeric(pgls$coefficients[2])
sink("surya_R_output_node_density_artifact.txt")
cat("=================\n")
cat("Node-Density Test\n")
cat("=================\n\n")
summary(pgls)
cat("\n")
cat(paste("Delta = ", round(delta, 2), sep = ""))
cat("\n")
sink()
