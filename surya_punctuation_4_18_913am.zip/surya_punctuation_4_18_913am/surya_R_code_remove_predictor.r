# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


# Load and prepare data ----
dat <- read.table("surya_BayesTraits_data_path_lengths_nodes.txt", sep = "\t")
dat <- dat[, -3]
colnames(dat) <- c("genome", "path")
dat$genome <- sQuote(dat$genome)

# Write data frame to a tab-delimited text file ----
write.table(
  dat,
  file = "surya_BayesTraits_data_path_lengths.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
