# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(nlme)
library(phytools)


# Read tree ----
tree <- read.tree(file = "surya_tree_1996_leitner_etal_hiv1.nwk")

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Define correlation matrix ----
corr <- corPagel(value = 1, phy = tree, fixed = TRUE)

# Define variance weights ----
w <- diag(vcv)

# Load and prepare data ----
dat <- read.table(
  "data_1996_leitner_etal_hiv1_node_transmission.txt",
  sep = "\t"
)
colnames(dat) <- c("patient", "node", "transmission")
rownames(dat) <- dat$patient
dat <- dat[match(tree$tip.label, dat$patient), ]
dat$node <- as.numeric(dat$node)
dat$transmission <- as.numeric(dat$transmission)

# Apply Anscombe transform to node count -----
dat$node_ans <- 2 * (sqrt(dat$node+(3/8)))
# Back-transformation: a = (a'/2)^2 - (1/8)  # 1/8 not 3/8, to mitigate bias

# Fit intercept-only model ----
pgls_int <- gls(
  node_ans ~ 1,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_int <- summary(pgls_int)
mean_phylo <- as.numeric(pgls_int$coefficients[1])
sigma2 <- sum_int$sigma^2
sink(
  "surya_leitner_R_output_regression_node_transmission_intercept_lambda1.txt"
)
cat("===========================\n")
cat("Regression (Intercept-Only)\n")
cat("===========================\n\n")
summary(pgls_int)
cat("\n")
sum_int$tTable
cat("\n")
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Fit regression model ----
pgls_reg <- gls(
  node_ans ~ transmission,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_reg <- summary(pgls_reg)
res_raw <- as.numeric(pgls_reg$residuals)
res_null <- as.matrix(dat$node_ans - mean_phylo)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_reg$sigma^2
sink("surya_leitner_R_output_regression_node_transmission_lambda1.txt")
cat("==========\n")
cat("Regression\n")
cat("==========\n\n")
summary(pgls_reg)
cat("\n")
sum_reg$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()
