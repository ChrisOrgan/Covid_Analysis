# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
dat_1 <- read.table(
  "data_2005_lemey_etal_hiv1_node_transmission_b90pop_c02pop.txt",
  sep = "\t",
  header = TRUE
)
dat_2 <- read.table(
  "data_2005_lemey_etal_hiv1_node_transmission_b90pop_c94pop.txt",
  sep = "\t",
  header = TRUE
)
dat_3 <- read.table(
  "data_2005_lemey_etal_hiv1_node_transmission_b96pop_c02pop.txt",
  sep = "\t",
  header = TRUE
)
dat_4 <- read.table(
  "data_2005_lemey_etal_hiv1_node_transmission_b96pop_c94pop.txt",
  sep = "\t",
  header = TRUE
)
dat_1$node <- as.numeric(dat_1$node)
dat_2$node <- as.numeric(dat_2$node)
dat_3$node <- as.numeric(dat_3$node)
dat_4$node <- as.numeric(dat_4$node)
dat_1$transmission <- as.numeric(dat_1$transmission)
dat_2$transmission <- as.numeric(dat_2$transmission)
dat_3$transmission <- as.numeric(dat_3$transmission)
dat_4$transmission <- as.numeric(dat_4$transmission)

# Plot scatter plots ----
plot_reg_1 <-
  ggplot(dat_1, aes(transmission, node)) +
    geom_jitter(size = 0.3, width = 0.1, height = 0.1) +
    geom_segment(
      x = min(dat_1$transmission),
      xend = max(dat_1$transmission),
      y = (2.713308/2)^2 - (1/8),
      yend = (2.713308/2)^2 - (1/8),
      color = "red",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 1, 2)) +
    scale_y_continuous(breaks = c(1, 3, 5)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(
      title = bquote(bold("Belgian HIV-1 Cluster")),
      subtitle = "b90pop & c02pop\n",
      x = "\nTransmission count",
      y = "Node count\n"
    )
plot_reg_2 <-
  ggplot(dat_2, aes(transmission, node)) +
    geom_jitter(size = 0.3, width = 0.1, height = 0.1) +
    stat_function(
      color = "red",
      size = 0.3,
      fun = function(transmission){((2.506667 + 0.5273393*transmission)/2)^2 - (1/8)}
    ) +
    scale_x_continuous(breaks = c(0, 1, 2)) +
    scale_y_continuous(breaks = c(1, 3, 5)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(
      title = bquote(bold("Belgian HIV-1 Cluster")),
      subtitle = "b90pop & c94pop\n",
      x = "\nTransmission count",
      y = "Node count\n"
    )
plot_reg_3 <-
  ggplot(dat_3, aes(transmission, node)) +
    geom_jitter(size = 0.3, width = 0.1, height = 0.1) +
    geom_segment(
      x = min(dat_3$transmission),
      xend = max(dat_3$transmission),
      y = (2.867348/2)^2 - (1/8),
      yend = (2.867348/2)^2 - (1/8),
      color = "red",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 1, 2)) +
    scale_y_continuous(breaks = c(1, 3, 5)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(
      title = bquote(bold("Belgian HIV-1 Cluster")),
      subtitle = "b96pop & c02pop\n",
      x = "\nTransmission count",
      y = "Node count\n"
    )
plot_reg_4 <-
  ggplot(dat_4, aes(transmission, node)) +
    geom_jitter(size = 0.3, width = 0.1, height = 0.1) +
    geom_segment(
      x = min(dat_4$transmission),
      xend = max(dat_4$transmission),
      y = (2.887448/2)^2 - (1/8),
      yend = (2.887448/2)^2 - (1/8),
      color = "red",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 1, 2)) +
    scale_y_continuous(breaks = c(1, 3, 5)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(
      title = bquote(bold("Belgian HIV-1 Cluster")),
      subtitle = "b96pop & c94pop\n",
      x = "\nTransmission count",
      y = "Node count\n"
    )

# Save scatter plots ----
CairoPDF("surya_lemey_figure_regression_b90pop_c02pop.pdf", width = 2.375,
         height = 1.75)
print(plot_reg_1)
graphics.off()
CairoSVG("surya_lemey_figure_regression_b90pop_c02pop.svg", width = 2.375,
         height = 1.75)
print(plot_reg_1)
graphics.off()
CairoPDF("surya_lemey_figure_regression_b90pop_c94pop.pdf", width = 2.375,
         height = 1.75)
print(plot_reg_2)
graphics.off()
CairoSVG("surya_lemey_figure_regression_b90pop_c94pop.svg", width = 2.375,
         height = 1.75)
print(plot_reg_2)
graphics.off()
CairoPDF("surya_lemey_figure_regression_b96pop_c02pop.pdf", width = 2.375,
         height = 1.75)
print(plot_reg_3)
graphics.off()
CairoSVG("surya_lemey_figure_regression_b96pop_c02pop.svg", width = 2.375,
         height = 1.75)
print(plot_reg_3)
graphics.off()
CairoPDF("surya_lemey_figure_regression_b96pop_c94pop.pdf", width = 2.375,
         height = 1.75)
print(plot_reg_4)
graphics.off()
CairoSVG("surya_lemey_figure_regression_b96pop_c94pop.svg", width = 2.375,
         height = 1.75)
print(plot_reg_4)
graphics.off()
