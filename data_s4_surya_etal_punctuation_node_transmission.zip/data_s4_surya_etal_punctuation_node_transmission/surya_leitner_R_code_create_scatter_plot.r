# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
dat <- read.table(
  "data_1996_leitner_etal_hiv1_node_transmission.txt",
  sep = "\t",
  header = TRUE
)
dat$node <- as.numeric(dat$node)
dat$transmission <- as.numeric(dat$transmission)

# Plot scatter plots ----
plot_reg <-
  ggplot(dat, aes(transmission, node)) +
    geom_jitter(size = 0.3, width = 0.1, height = 0.1) +
    stat_function(
      color = "red",
      size = 0.3,
      fun = function(transmission){((2.5190357 + 0.5014116*transmission)/2)^2 - (1/8)}
    ) +
    scale_x_continuous(breaks = c(0, 1, 2)) +
    scale_y_continuous(breaks = c(1, 2, 3)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(
      title = bquote(bold("Swedish HIV-1 Cluster")),
      subtitle = " \n",
      x = "\nTransmission count",
      y = "Node count\n"
    )

# Save scatter plots ----
CairoPDF("surya_leitner_figure_regression.pdf", width = 2.375, height = 1.75)
print(plot_reg)
graphics.off()
CairoSVG("surya_leitner_figure_regression.svg", width = 2.375, height = 1.75)
print(plot_reg)
graphics.off()
