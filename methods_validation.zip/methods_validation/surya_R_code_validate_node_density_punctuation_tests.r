# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


# library(ape)  # v5.3
library(Cairo)  # v1.5.10
library(ggplot2)  # v3.2.1
library(ggthemes)  # v4.2.0
library(nlme)  # v3.1-143
library(phytools)  # v0.6.99
library(svglite)  # v1.2.2


# Simulate tree ----
set.seed(0)
tree <- rtree(n = 35)

# Set tree branches to be equal (positive control) ----
tree_positive <- compute.brlen(tree, 1)

# Make tree ultrametric (negative control) ----
tree_negative <- force.ultrametric(tree_positive, method = "extend")

# Write trees in the NEXUS format ----
writeNexus(tree = tree, file = "surya_tree_validation.nex")
writeNexus(tree = tree_positive, file = "surya_tree_validation_positive.nex")
writeNexus(tree = tree_negative, file = "surya_tree_validation_negative.nex")

# Add some random noises to branches of the control trees ----
tree_positive$edge.length <- jitter(tree_positive$edge.length, 0.05)
tree_negative$edge.length <- jitter(tree_negative$edge.length, 0.05)

# Decompose trees into a variance-covariance matrix ----
vcv <- vcv(phy = tree)
vcv_positive <- vcv(phy = tree_positive)
vcv_negative <- vcv(phy = tree_negative)

# Extract path lengths (diagonals of the matrix) ----
path <- diag(vcv)
path_positive <- diag(vcv_positive)
path_negative <- diag(vcv_negative)

# Extract nodes ----
node <- node_positive <- node_negative <- NULL
for (tip in 1:length(tree$tip.label)) {
  node[tip] <- length(
    nodepath(
      phy = tree,
      from = length(tree$tip.label) + 1,  # root
      to = tip
    )
   ) - 2  # minus the root and terminal tip
}
for (tip in 1:length(tree_positive$tip.label)) {
  node_positive[tip] <- length(
    nodepath(
      phy = tree_positive,
      from = length(tree_positive$tip.label) + 1,
      to = tip
    )
   ) - 2
}
for (tip in 1:length(tree_negative$tip.label)) {
  node_negative[tip] <- length(
    nodepath(
      phy = tree_negative,
      from = length(tree_negative$tip.label) + 1,
      to = tip
    )
   ) - 2
}

# Create data frames ----
dat <- data.frame(tree$tip.label, path, node)
dat_positive <- data.frame(tree_positive$tip.label, path_positive,
                           node_positive)
dat_negative <- data.frame(tree_negative$tip.label, path_negative,
                           node_negative)

# Define variance-covariance matrices for the node-density test ----
vcv_test <- corPagel(1, tree, fixed = TRUE)
vcv_test_positive <- corPagel(1, tree_positive, fixed = TRUE)
vcv_test_negative <- corPagel(1, tree_negative, fixed = TRUE)

# Detect the node-density artifact ----
# See https://stackoverflow.com/questions/18305852/power-regression-in-r-similar-to-excel
pgls <- gls(log(node) ~ log(path), data = dat, correlation = vcv_test)
beta <- exp(as.numeric(pgls$coefficients[1]))
delta <- as.numeric(pgls$coefficients[2])
sink("surya_R_output_validation_node_density.txt")
cat("=================\n")
cat("Node-Density Test\n")
cat("=================\n\n")
summary(pgls)
cat("\n")
cat(paste("Beta = ", round(beta, 3), "\n", sep = ""))
cat(paste("Delta = ", round(delta, 3), sep = ""))
cat("\n")
sink()
pgls_positive <- gls(
  log(node_positive) ~ log(path_positive),
  data = dat_positive,
  correlation = vcv_test_positive
)
beta_positive <- exp(as.numeric(pgls_positive$coefficients[1]))
delta_positive <- as.numeric(pgls_positive$coefficients[2])
sink("surya_R_output_validation_node_density_positive.txt")
cat("=================\n")
cat("Node-Density Test\n")
cat("=================\n\n")
summary(pgls_positive)
cat("\n")
cat(paste("Beta = ", round(beta_positive, 3), "\n", sep = ""))
cat(paste("Delta = ", round(delta_positive, 3), sep = ""))
cat("\n")
sink()
pgls_negative <- gls(
  log(node_negative) ~ log(path_negative),
  data = dat_negative,
  correlation = vcv_test_negative
)
beta_negative <- exp(as.numeric(pgls_negative$coefficients[1]))
delta_negative <- as.numeric(pgls_negative$coefficients[2])
sink("surya_R_output_validation_node_density_negative.txt")
cat("=================\n")
cat("Node-Density Test\n")
cat("=================\n\n")
summary(pgls_negative)
cat("\n")
cat(paste("Beta = ", round(beta_negative, 3), "\n", sep = ""))
cat(paste("Delta = ", round(delta_negative, 3), sep = ""))
cat("\n")
sink()

# Plot scatter plots ----
scatter_plot <-
  ggplot(dat, aes(path, node)) +
    geom_point(color = "gray", size = 0.5) +
    stat_function(
      color = "red",
      size = 1,
      fun = function(path){beta * path^delta}
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(
      subtitle = "Number of Nodes",
      x = "\nTotal Path Lengths",
      y = NULL
    )
scatter_plot_positive <-
  ggplot(dat_positive, aes(path_positive, node_positive)) +
    geom_point(color = "gray", size = 0.5) +
    stat_function(
      color = "red",
      size = 1,
      fun = function(path_positive) {
        beta_positive * path_positive^delta_positive
      }
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(
      subtitle = "Number of Nodes",
      x = "\nTotal Path Lengths",
      y = NULL
    )
scatter_plot_negative <-
  ggplot(dat_negative, aes(path_negative, node_negative)) +
    geom_point(color = "gray", size = 0.5) +
    stat_function(
      color = "red",
      size = 1,
      fun = function(path_negative) {
        beta_negative * path_negative^delta_negative
      }
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(
      subtitle = "Number of Nodes",
      x = "\nTotal Path Lengths",
      y = NULL
    )

# Save scatter plots ----
CairoPDF("surya_figure_validation_node_density.pdf", width = 3.2675,
         height = 3.2675)
print(scatter_plot)
graphics.off()
CairoPDF("surya_figure_validation_node_density_positive.pdf", width = 3.2675,
         height = 3.2675)
print(scatter_plot_positive)
graphics.off()
CairoPDF("surya_figure_validation_node_density_negative.pdf", width = 3.2675,
         height = 3.2675)
print(scatter_plot_negative)
graphics.off()

# Test for punctuation ----
pgls_punceq <- gls(path ~ node, data = dat, correlation = vcv_test)
beta0 <- as.numeric(pgls_punceq$coefficients[1])
beta1 <- as.numeric(pgls_punceq$coefficients[2])
sum_punceq <- summary(pgls_punceq)
p_val <- sum_punceq$tTable[8]
sink("surya_R_output_validation_punctuation.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_punceq)
cat("\n")
cat(paste("Intercept = ", round(beta0, 3), "\n", sep = ""))
cat(paste("Slope = ", round(beta1, 3), "\n", sep = ""))
cat(paste("P-value (slope) = ", p_val, sep = ""))
cat("\n")
sink()
pgls_punceq_positive <- gls(
  path_positive ~ node_positive,
  data = dat_positive,
  correlation = vcv_test_positive
)
beta0_positive <- as.numeric(pgls_punceq_positive$coefficients[1])
beta1_positive <- as.numeric(pgls_punceq_positive$coefficients[2])
sum_punceq_positive <- summary(pgls_punceq_positive)
p_val_positive <- sum_punceq_positive$tTable[8]
sink("surya_R_output_validation_punctuation_positive.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_punceq_positive)
cat("\n")
cat(paste("Intercept = ", round(beta0_positive, 3), "\n", sep = ""))
cat(paste("Slope = ", round(beta1_positive, 3), "\n", sep = ""))
cat(paste("P-value (slope) = ", p_val_positive, sep = ""))
cat("\n")
sink()
pgls_punceq_negative <- gls(
  path_negative ~ node_negative,
  data = dat_negative,
  correlation = vcv_test_negative
)
beta0_negative <- as.numeric(pgls_punceq_negative$coefficients[1])
beta1_negative <- as.numeric(pgls_punceq_negative$coefficients[2])
sum_punceq_negative <- summary(pgls_punceq_negative)
p_val_negative <- sum_punceq_negative$tTable[8]
sink("surya_R_output_validation_punctuation_negative.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_punceq_negative)
cat("\n")
cat(paste("Intercept = ", round(beta0_negative, 3), "\n", sep = ""))
cat(paste("Slope = ", round(beta1_negative, 3), "\n", sep = ""))
cat(paste("P-value (slope) = ", p_val_negative, sep = ""))
cat("\n")
sink()

# Cross-check results using the website http://www.evolution.rdg.ac.uk/pe/index.html
