# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(ape)


# Delete nine genomes from the FASTA file ----
seq_sars_cov_2_temp <- read.FASTA("msa_trimmed_filtered_masked_clustered.fasta")
seq_names <- names(seq_sars_cov_2_temp)
problem <- read.table("surya_R_output_outliers_problematic.txt", sep = "\t")
problem <- as.character(problem$V1)
problem[problem == "hCoV-19/South_Africa/R02606/2020|EPI_ISL_435058|2020-03-11|Africa"] <-
  "hCoV-19/South Africa/R02606/2020|EPI_ISL_435058|2020-03-11|Africa"
seq_sars_cov_2 <- seq_sars_cov_2_temp[!seq_names %in% problem]

# Write FASTA file ----
write.FASTA(
  seq_sars_cov_2,
  file = "msa_trimmed_filtered_masked_clustered_v2.fasta"
)
