# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.
# Part of the codes were adopted from Kamil Slowikowski.
# See https://slowkow.com/notes/ggplot2-color-by-density/


library(Cairo)  # v1.5.12
library(ggplot2)  # v3.3.0
library(ggthemes)  # v4.2.0
library(MASS)  # v7.3.51.5
library(svglite)  # v1.2.3
library(viridis)  # v0.5.1


# Load and prepare data ----
dat <- read.table("surya_BayesTraits_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
meta <- read.delim(
  "nextstrain_ncov_global_metadata.tsv",
  header = TRUE,
  sep = "\t"
)
dat <- dat[match(meta$Strain, dat$genome), ]
dat <- cbind(dat, meta$Region)
colnames(dat)[4] <- "continent"
dat_africa <- dat[dat$continent == "Africa", ]
dat_asia <- dat[dat$continent == "Asia", ]
dat_europe <- dat[dat$continent == "Europe", ]
dat_namerica <- dat[dat$continent == "North America", ]
dat_oceania <- dat[dat$continent == "Oceania", ]
dat_samerica <- dat[dat$continent == "South America", ]
dat_out <- read.table("surya_R_output_outliers.txt")
colnames(dat_out) <- c("outlier")
dat_edit <- dat[!dat$genome %in% as.character(dat_out$outlier), ]

# Plot scatter plots ----
## Get density of points in 2 dimensions.
## @param x A numeric vector.
## @param y A numeric vector.
## @param n Create a square n by n grid to compute density.
## @return The density within each square.
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}
dat$density <- get_density(dat$node, dat$path, n = 3000)
plot_reg <-
  ggplot(dat, aes(node, path, color = density)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.00000000007633297,
      yend = 0.00000000007633297,
      color = "dark gray",
      size = 0.5
    ) +
    scale_colour_gradient(low = "gray90", high = "gray10") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations)\n",
      color = "Density\n"
    )
dat_edit$density <- get_density(dat_edit$node, dat_edit$path, n = 3000)
plot_reg_out <-
  ggplot(dat_edit, aes(node, path, color = density)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.00000000007633297,
      yend = 0.00000000007633297,
      color = "dark gray",
      size = 0.5
    ) +
    scale_colour_gradient(low = "gray90", high = "gray10") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations)\n",
      color = "Density\n"
    )
plot_region <-
  ggplot(dat, aes(node, path, color = continent)) +
    geom_jitter(size = 0.75, height = 0.2, width = 0.2, alpha = 0.3) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(
      legend.direction = "vertical",
      legend.position = "right"
    ) +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations)\n",
      color = NULL
    )
plot_reg_region <-
  ggplot(dat, aes(node, path, color = continent)) +
    geom_point(size = 0.75, alpha = 0.1) +
    geom_segment(
      x = min(dat_africa$node),
      xend = max(dat_africa$node),
      y = 0.0000000001182959 + -0.00000000000389726*min(dat_africa$node),
      yend = 0.0000000001182959 + -0.00000000000389726*max(dat_africa$node),
      color = "#F8766D",
      size = 1
    ) +
    geom_segment(
      x = min(dat_asia$node),
      xend = max(dat_asia$node),
      y = 0.00000000010378226 + -0.0000000000034254529*min(dat_asia$node),
      yend = 0.00000000010378226 + -0.0000000000034254529*max(dat_asia$node),
      color = "#B79F00",
      size = 1
    ) +
    geom_segment(
      x = min(dat_europe$node),
      xend = max(dat_europe$node),
      y = 0.0000000001044907 + 0.0000000001187299575*min(dat_europe$node),
      yend = 0.0000000001044907 + 0.0000000001187299575*max(dat_europe$node),
      color = "#00BA38",
      size = 1
    ) +
    geom_segment(
      x = min(dat_namerica$node),
      xend = max(dat_namerica$node),
      y = 0.00000000010609832 + -0.0000000000035044702*min(dat_namerica$node),
      yend = 0.00000000010609832 +
             -0.0000000000035044702*max(dat_namerica$node),
      color = "#00BFC4",
      size = 1
    ) +
    geom_segment(
      x = min(dat_oceania$node),
      xend = max(dat_oceania$node),
      y = 0.00000000010580019 + -0.00000000000348554*min(dat_oceania$node),
      yend = 0.00000000010580019 + -0.00000000000348554*max(dat_oceania$node),
      color = "#619CFF",
      size = 1
    ) +
    geom_segment(
      x = min(dat_samerica$node),
      xend = max(dat_samerica$node),
      y = 0.000000000109484594 + -0.0000000000036524467*min(dat_samerica$node),
      yend = 0.000000000109484594 +
             -0.0000000000036524467*max(dat_samerica$node),
      color = "#F564E3",
      size = 1
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(
      legend.direction = "vertical",
      legend.position = "right"
    ) +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations)\n",
      color = NULL
    )
plot_reg_pop <-
  ggplot(dat, aes(node, path, color = continent)) +
    geom_point(size = 0.75, alpha = 0.1) +
    geom_segment(
      x = min(dat_africa$node),
      xend = max(dat_africa$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_africa$node) +
          -0.0000000000000000000004407735*1340598113 +
          0.00000000000000000000001649282*min(dat_africa$node)*1340598113,          
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_africa$node) +
             -0.0000000000000000000004407735*1340598113 +
             0.00000000000000000000001649282*max(dat_africa$node)*1340598113,
      color = "#F8766D",
      size = 1
    ) +
    geom_segment(
      x = min(dat_asia$node),
      xend = max(dat_asia$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_asia$node) +
          -0.0000000000000000000004407735*4641054786 +
          0.00000000000000000000001649282*min(dat_asia$node)*4641054786,
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_asia$node) +
             -0.0000000000000000000004407735*4641054786 +
             0.00000000000000000000001649282*max(dat_asia$node)*4641054786,
      color = "#B79F00",
      size = 1
    ) +
    geom_segment(
      x = min(dat_europe$node),
      xend = max(dat_europe$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_europe$node) +
          -0.0000000000000000000004407735*747636045 +
          0.00000000000000000000001649282*min(dat_europe$node)*747636045,
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_europe$node) +
             -0.0000000000000000000004407735*747636045 + 
             0.00000000000000000000001649282*max(dat_europe$node)*747636045,
      color = "#00BA38",
      size = 1
    ) +
    geom_segment(
      x = min(dat_namerica$node),
      xend = max(dat_namerica$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_namerica$node) +
          -0.0000000000000000000004407735*368092846 +
          0.00000000000000000000001649282*min(dat_namerica$node)*368092846,
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_namerica$node) +
             -0.0000000000000000000004407735*368092846 + 
             0.00000000000000000000001649282*max(dat_namerica$node)*368092846,
      color = "#00BFC4",
      size = 1
    ) +
    geom_segment(
      x = min(dat_oceania$node),
      xend = max(dat_oceania$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_oceania$node) +
          -0.0000000000000000000004407735*42677809 +
          0.00000000000000000000001649282*min(dat_oceania$node)*42677809,
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_oceania$node) +
             -0.0000000000000000000004407735*42677809 + 
             0.00000000000000000000001649282*max(dat_oceania$node)*42677809,
      color = "#619CFF",
      size = 1
    ) +
    geom_segment(
      x = min(dat_samerica$node),
      xend = max(dat_samerica$node),
      y = 0.0000000001057456 + -0.000000000003491736*min(dat_samerica$node) +
          -0.0000000000000000000004407735*653739130 +
          0.00000000000000000000001649282*min(dat_samerica$node)*653739130,
      yend = 0.0000000001057456 + -0.000000000003491736*max(dat_samerica$node) +
             -0.0000000000000000000004407735*653739130 + 
             0.00000000000000000000001649282*max(dat_samerica$node)*653739130,
      color = "#F564E3",
      size = 1
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(
      legend.direction = "vertical",
      legend.position = "right"
    ) +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations)\n",
      color = NULL
    )

# Save scatter plots ----
CairoPDF("surya_figure_punctuation.pdf", width = 5, height = 2.94)
print(plot_reg)
graphics.off()
CairoSVG("surya_figure_punctuation.svg", width = 5, height = 2.94)
print(plot_reg)
graphics.off()
CairoPDF("surya_figure_punctuation_no_outliers.pdf", width = 4.75,
         height = 2.94)
print(plot_reg_out)
graphics.off()
CairoSVG("surya_figure_punctuation_no_outliers.svg", width = 4.75,
         height = 2.94)
print(plot_reg_out)
graphics.off()
CairoPDF("surya_figure_punctuation_region.pdf", width = 6.535, height = 4.039)
print(plot_region)
graphics.off()
CairoSVG("surya_figure_punctuation_region.svg", width = 6.535, height = 4.039)
print(plot_region)
graphics.off()
CairoPDF("surya_figure_punctuation_pop_lines.pdf", width = 6.535,
         height = 4.039)
print(plot_reg_pop)
graphics.off()
CairoSVG("surya_figure_punctuation_pop_lines.svg", width = 6.535,
         height = 4.039)
print(plot_reg_pop)
graphics.off()
