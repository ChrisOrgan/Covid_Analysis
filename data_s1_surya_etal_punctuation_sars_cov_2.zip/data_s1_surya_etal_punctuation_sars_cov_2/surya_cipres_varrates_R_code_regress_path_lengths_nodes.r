# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)  # v5.3
library(car)  # v3.0.9
library(nlme)  # v3.1.147
library(phytools)  # v0.7.20


# Read tree ----
tree <- read.nexus(file = "surya_cipres_tree_collapsed_v4.nex")

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Define correlation matrix ----
corr <- corPagel(value = 1, phy = tree, fixed = TRUE)

# Define variance weights ----
w <- diag(vcv)

# Load and prepare data ----
dat <- read.table(
  "surya_cipres_varrates_R_data_path_lengths_nodes.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path_mol", "path_time", "node")
rownames(dat) <- dat$genome
dat <- dat[match(tree$tip.label, dat$genome), ]

# Fit intercept-only model ----
pgls_int <- gls(
  path_mol ~ 1,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_int <- summary(pgls_int)
mean_phylo <- as.numeric(pgls_int$coefficients[1])
sigma2 <- sum_int$sigma^2
sink("surya_cipres_varrates_R_output_regression_intercept_lambda1.txt")
cat("===========================\n")
cat("Regression (Intercept-Only)\n")
cat("===========================\n\n")
summary(pgls_int)
cat("\n")
sum_int$tTable
cat("\n")
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Fit model with time path lengths ----
pgls_time <- gls(
  path_mol ~ path_time,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_time <- summary(pgls_time)
res_raw <- as.numeric(pgls_time$residuals)
res_null <- as.matrix(dat$path_mol - mean_phylo)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_time$sigma^2
sink("surya_cipres_varrates_R_output_regression_time_lambda1.txt")
cat("==========\n")
cat("Regression\n")
cat("==========\n\n")
summary(pgls_time)
cat("\n")
sum_time$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Fit model with time path lengths and node count ----
pgls_tn <- gls(
  path_mol ~ path_time + node,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_tn <- summary(pgls_tn)
res_raw <- as.numeric(pgls_tn$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_tn$sigma^2
sink("surya_cipres_varrates_R_output_regression_time_node_lambda1.txt")
cat("==========\n")
cat("Regression\n")
cat("==========\n\n")
summary(pgls_tn)
cat("\n")
sum_tn$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Test for interaction ----
pgls_inter <- gls(
  path_mol ~ path_time * node,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_inter <- summary(pgls_inter)
res_raw <- as.numeric(pgls_inter$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_inter$sigma^2
sink("surya_cipres_varrates_R_output_regression_time_node_inter_lambda1.txt")
cat("==========\n")
cat("Regression\n")
cat("==========\n\n")
summary(pgls_inter)
cat("\n")
sum_inter$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Calculate variance inflation factors (VIFs) ----
models <- NULL
model[[1]] <- pgls_int
model[[2]] <- pgls_time
model[[3]] <- pgls_tn
model[[4]] <- pgls_inter
sink("surya_cipres_varrates_R_output_vif.txt")
cat("==========================\n")
cat("Variance Inflation Factors\n")
cat("==========================\n\n")
for (model in 1:length(models)) {
  print(vif(models[[model]]))
  cat("")
}
sink()
