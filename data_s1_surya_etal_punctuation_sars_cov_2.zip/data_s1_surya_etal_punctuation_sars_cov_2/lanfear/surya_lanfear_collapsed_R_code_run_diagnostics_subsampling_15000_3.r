# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(ape)
library(ggExtra)
library(ggplot2)
library(ggthemes)
library(svglite)


memory.limit(size = 5e+06)

# Read tree ----
tree <- read.nexus(file = "lanfear_tree_collapsed_subsampling_15000_3.nex")

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Write function `Dfun` ----
## See https://github.com/cran/caper/blob/master/R/pgls.R
Dfun <- function(Cmat) {
  iCmat <- solve(Cmat, tol = 2e-18)
  svdCmat <- La.svd(iCmat)
  D <- svdCmat$u %*% diag(sqrt(svdCmat$d)) %*% t(svdCmat$v)
  return(t(D))
}

# Load and prepare data ----
dat <- read.table(
  "surya_lanfear_collapsed_R_data_path_lengths_nodes_subsampling_15000_3.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path", "node")
dat$fitted_values <- 1.536654e-10 + 3.041334e-06*dat$node
dat$res_raw <- dat$path - dat$fitted_values
dat$res_phy <- as.vector(Dfun(vcv) %*% dat$res_raw)

# Plot marginal histogram scatter plots of residuals ----
plot_diag <-
  ggplot(dat, aes(fitted_values, res_phy)) +
    geom_point(color = "gray", size = 0.5) +
    geom_smooth(
      color = "red",
      size = 1,
      method = "loess",
      se = FALSE
    ) +
    scale_y_reverse() +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nFitted values", y = "Residuals\n")
plot_diag <- ggMarginal(plot_diag, type = "density", margins = "y", size = 1.75)

# Save diagnostic plots ----
ggsave("surya_lanfear_collapsed_figure_punctuation_diagnostics_3.pdf",
       width = 4.75, height = 4, device = cairo_pdf, plot_diag)
graphics.off()
ggsave("surya_lanfear_collapsed_figure_punctuation_diagnostics_3.svg",
       width = 4.75, height = 4, plot_diag)
graphics.off()
