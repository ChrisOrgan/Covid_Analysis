# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(nlme)
library(phytools)


memory.limit(size = 6e+06)

# Read tree ----
tree_ori <- read.nexus(file = "lanfear_tree.nex")

# Subsample data and test for punctuation for each subsample ----
for (subs in 1:1) {
  tree <- tree_ori
  tree$edge.length <-
    # Add random noise to avoid a singular variance-covariance matrix
    tree$edge.length + abs(rnorm(tree$edge.length, mean = 0, sd = 1e-10))
  subsample <- sample(tree$tip.label, size = 15000)
  tree_edit <- keep.tip(phy = tree, tip = subsample)
  vcv <- vcv(phy = tree_edit)
  path <- diag(vcv)
  node <- NULL
  for (genome in 1:length(tree_edit$tip.label)) {
    node[genome] <- length(
      nodepath(
        phy = tree_edit,
        from = length(tree_edit$tip.label) + 1,
        to = genome
      )
    ) - 2
  }
  dat_edit <- data.frame(tree_edit$tip.label, path, node)
  colnames(dat_edit) <- c("genome", "path", "node")
  rownames(dat_edit) <- dat_edit$genome
  dat_edit <- dat_edit[match(tree_edit$tip.label, rownames(dat_edit)), ]
  corr <- corPagel(value = 1, phy = tree_edit, fixed = TRUE)
  w <- diag(vcv)
  pgls_int <- gls(
    path ~ 1,
    data = dat_edit,
    correlation = corr,
    weights = varFixed(~w),
    method = "ML"
  )
  mean_phylo <- as.numeric(pgls_int$coefficients[1])
  pgls <- gls(
    path ~ node,
    data = dat_edit,
    correlation = corr,
    weights = varFixed(~w),
    method = "ML"
  )
  summ <- summary(pgls)
  beta0 <- as.numeric(pgls$coefficients[1])
  beta1 <- as.numeric(pgls$coefficients[2])
  sig2 <- summ$sigma^2
  res_raw <- as.numeric(pgls$residuals)
  res_null <- as.matrix(dat_edit$path - mean_phylo)
  sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
  sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
  r2 <- 1 - sse/sst
  se_b0 <- summ$tTable[3]
  se_b1 <- summ$tTable[4]
  p_val <- summ$tTable[8]
  sink("surya_lanfear_R_output_subsampling_results_15000_1.txt")
  cat("================\n")
  cat("Punctuation Test\n")
  cat("================\n\n")
  print(summ)
  cat("\n")
  print(summ$tTable)
  cat("\n")
  cat(paste("R-squared = ", r2, "\n", sep = ""))
  cat(paste("Variance = ", sig2, "\n", sep = ""))
  cat("\n")
  sink()
  summ_int <- summary(pgls_int)
  sink("surya_lanfear_R_output_subsampling_results_15000_1.txt", append = TRUE)
  cat("==============\n")
  cat("Intercept-Only\n")
  cat("==============\n\n")
  print(summ_int)
  cat("\n")
  print(summ_int$tTable)
  cat("\n")
  cat("\n")
  sink()
  pgls_nda <- gls(
    log(node + 1) ~ log(path),
    data = dat_edit,
    correlation = corr,
    weights = varFixed(~w),
    method = "ML"
  )
  summ_nda <- summary(pgls_nda)
  delta <- as.numeric(pgls_nda$coefficients[2])
  sink("surya_lanfear_R_output_subsampling_results_15000_1.txt", append = TRUE)
  cat("=================\n")
  cat("Node-Density Test\n")
  cat("=================\n\n")
  print(summ_nda)
  cat("\n")
  cat(paste("Delta = ", delta, sep = ""))
  cat("\n")
  sink()
}

# Write the subsample data frame to a tab-delimited text file ----
write.table(
  dat_edit,
  file = "surya_lanfear_R_data_path_lengths_nodes_subsampling_15000_1.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)

# Write tree to a NEXUS file ----
writeNexus(tree = tree_edit, file = "lanfear_tree_subsampling_15000_1.nex")
