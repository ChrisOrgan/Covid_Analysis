# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(LaplacesDemon)


# Load and prepare data ----
setwd("subsampling_lanfear_collapsed_1000")
slope <- read.table("surya_lanfear_collapsed_R_output_subsampling_beta1.txt")
r2 <- read.table("surya_lanfear_collapsed_R_output_subsampling_r2.txt")
setwd("..")
slope$iteration <- r2$iteration <- 1:1000
colnames(slope)[1] <- "slopes"
colnames(r2)[1] <- "r2"

# Determine modes ----
modes_slope <- Modes(slope$slopes)
# modes_slope
# $modes
# [1] 3.382281e-06 4.925581e-05
#
# $mode.dens
# [1] 61353.03 17263.58
#
# $size
# [1] 0.7252770 0.2591343
modes_r2 <- Modes(r2$r2)
# modes_r2
# [1] 0.0104473 0.1539446
#
# $mode.dens
# [1] 19.512102  4.759388
#
# $size
# [1] 0.7268386 0.2625196
