# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.
# Part of the codes were adopted from Sandra L. Ament-Velásquez.
# See http://evoslav.blogspot.com/2015/01/how-to-collapse-unsupported-branches-of.html


# library(ape)
library(phytools)


# Read and prepare tree ----
setwd("GISAID-hCoV-19-phylogeny-2020-12-05")
tree <- read.newick(file = "global.tree")
setwd("..")
tree$node.label <- as.numeric(tree$node.label)
# tree
#
# Phylogenetic tree with 175511 tips and 129236 internal nodes.
#
# Tip labels:
#   EPI_ISL_406801, EPI_ISL_413750, EPI_ISL_414690, EPI_ISL_421247, EPI_ISL_428476, EPI_ISL_428470, ...
# Node labels:
#   NA, NA, 0, 0.94, 0, 1, ...
#
# Rooted; includes branch lengths.

# Locate nodes with low support values (< 0.5) ----
bad_nodes <- which(tree$node.label < 0.5) + length(tree$tip.label)

# Get the actual indexes of the nodes with low support ----
bad_node_indexes <- c()
for(node in bad_nodes) {
  bad_node_indexes <- c(bad_node_indexes, which(tree$edge[, 2] == node))
}

# Make the branch length of the bad nodes = 0 ----
tree$edge.length[bad_node_indexes] <- 0

# Convert the branches with length = 0 to polytomies ----
tree_poly <- di2multi(tree)
tree_poly$node.label <- NULL
# tree_poly
#
# Phylogenetic tree with 175511 tips and 33672 internal nodes.
#
# Tip labels:
#   EPI_ISL_406801, EPI_ISL_413750, EPI_ISL_414690, EPI_ISL_421247, EPI_ISL_428476, EPI_ISL_428470, ...
#
# Unrooted; includes branch lengths.

# Write trees in the NEXUS format ----
writeNexus(tree = tree, file = "lanfear_tree.nex")
writeNexus(tree = tree_poly, file = "lanfear_tree_collapsed.nex")
