# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.
# Part of the codes were adopted from Kamil Slowikowski.
# See https://slowkow.com/notes/ggplot2-color-by-density/


library(Cairo)
library(ggplot2)
library(ggthemes)
library(MASS)
library(svglite)


# Load and prepare data ----
dat <- read.table(
  "surya_lanfear_R_data_path_lengths_nodes_subsampling_15000_3.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path", "node")

# Plot scatter plots ----
# Get density of points in 2 dimensions.
# @param x A numeric vector.
# @param y A numeric vector.
# @param n Create a square n by n grid to compute density.
# @return The density within each square.
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}
dat$density <- get_density(dat$node, dat$path, n = 3000)
plot_reg <-
  ggplot(dat, aes(node, path, color = density)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 4.208683e-11,
      yend = 4.208683e-11,
      color = "dark gray",
      size = 0.5
    ) +
    scale_colour_gradient(low = "gray90", high = "gray10") +
    scale_x_continuous(breaks = c(0, 20, 40, 60, 80)) +
    guides(colour = guide_colourbar(barwidth = 0.25, ticks = FALSE)) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations/site)\n",
      color = "Density\n"
    )

# Save scatter plots ----
CairoPDF("surya_lanfear_figure_punctuation_3.pdf", width = 4.75, height = 4)
print(plot_reg)
graphics.off()
## CairoSVG("surya_lanfear_figure_punctuation_3.svg", width = 4.75, height = 4)
## print(plot_reg)
## graphics.off()
