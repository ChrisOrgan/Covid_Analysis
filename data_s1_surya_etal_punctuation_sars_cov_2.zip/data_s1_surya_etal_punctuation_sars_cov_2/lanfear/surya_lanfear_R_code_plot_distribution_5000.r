# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
setwd("subsampling_lanfear_5000")
slope <- read.table("surya_lanfear_R_output_subsampling_beta1.txt")
r2 <- read.table("surya_lanfear_R_output_subsampling_r2.txt")
p <- read.table("surya_lanfear_R_output_subsampling_p.txt")
delta <- read.table("surya_lanfear_R_output_subsampling_delta.txt")
setwd("..")
slope$iteration <- r2$iteration <- p$iteration <- delta$iteration <- 1:100
colnames(slope)[1] <- "slopes"
colnames(r2)[1] <- "r2"
colnames(p)[1] <- "p"
colnames(delta)[1] <- "delta"

# Plot distributions ----
plot_dist_slope <-
  ggplot(slope, aes(slopes)) +
    geom_segment(
      x = 0,
      xend = 0,
      y = 0,
      yend = 1.5e+08,
      linetype = "dashed",
      color = "gray40",
      size = 0.5
    ) +
    annotate("text", x = 0, y = 1.5e+08, label = "") +
    geom_density(color = "black") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    labs(x = "Slope", y = NULL)
plot_dist_r2 <-
  ggplot(r2, aes(r2)) +
    geom_segment(
      x = 0,
      xend = 0,
      y = 0,
      yend = 10500,
      linetype = "dashed",
      color = "gray40",
      size = 0.5
    ) +
    annotate("text", x = 0, y = 10500, label = "") +
    geom_density(color = "black") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    labs(x = expression(paste(italic("R")^italic("2"))), y = NULL)
plot_dist_p <-
  ggplot(p, aes(p)) +
    geom_segment(
      x = 0.05,
      xend = 0.05,
      y = 0,
      yend = 5.75,
      linetype = "dashed",
      color = "gray40",
      size = 0.5
    ) +
    annotate("text", x = 0, y = 5.75, label = "") +
    geom_density(color = "black") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    labs(x = expression(paste(italic("P"), " value", sep = "")), y = NULL)
plot_dist_delta <-
  ggplot(delta, aes(delta)) +
    xlim(min(delta), 1) +
    geom_segment(
      x = 1,
      xend = 1,
      y = 0,
      yend = 4.3,
      linetype = "dashed",
      color = "gray40",
      size = 0.5
    ) +
    annotate("text", x = 0, y = 4.3, label = "") +
    geom_density(color = "black") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    labs(x = expression(paste(italic(delta))), y = NULL)

# Save scatter plots ----
CairoPDF("surya_lanfear_figure_slope_distribution_subsampling_5000.pdf",
         width = 4.75, height = 2.94)
print(plot_dist_slope)
graphics.off()
#3 CairoSVG("surya_lanfear_figure_slope_distribution_subsampling_5000.svg",
#3          width = 4.75, height = 2.94)
#3 print(plot_dist_slope)
#3 graphics.off()
CairoPDF("surya_lanfear_figure_r2_distribution_subsampling_5000.pdf",
         width = 4.75, height = 2.94)
print(plot_dist_r2)
graphics.off()
## CairoSVG("surya_lanfear_figure_r2_distribution_subsampling_5000.svg",
##          width = 4.75, height = 2.94)
## print(plot_dist_r2)
## graphics.off()
CairoPDF("surya_lanfear_figure_p_distribution_subsampling_5000.pdf",
         width = 4.75, height = 2.94)
print(plot_dist_p)
graphics.off()
## CairoSVG("surya_lanfear_figure_p_distribution_subsampling_5000.svg",
##          width = 4.75, height = 2.94)
## print(plot_dist_p)
## graphics.off()
CairoPDF("surya_lanfear_figure_delta_distribution_subsampling_5000.pdf",
         width = 4.75, height = 2.94)
print(plot_dist_delta)
graphics.off()
## CairoSVG("surya_lanfear_figure_delta_distribution_subsampling_5000.svg",
##          width = 4.75, height = 2.94)
## print(plot_dist_delta)
## graphics.off()
