# Written by Kevin Surya, 2021.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(nlme)
library(phytools)


memory.limit(size = 6e+06)

# Read tree ----
tree <- read.nexus(file = "surya_cipres_tree_collapsed.nex")

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Define correlation matrix ----
corr <- corPagel(value = 1, phy = tree, fixed = TRUE)

# Define variance weights ----
w <- diag(vcv)

# Load and prepare data ----
dat <- read.table("surya_cipres_R_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
rownames(dat) <- dat$genome
dat <- dat[match(tree$tip.label, dat$genome), ]
mean_phylo <- 3.334559e-06
res_null <- as.matrix(dat$path - mean_phylo)
dat$node2 <- dat$node^2

# Test for punctuation (asymptote) ----
pgls_as <- gls(
  path ~ sqrt(node),
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_as <- summary(pgls_as)
res_raw <- as.numeric(pgls_as$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_as$sigma^2
sink("surya_cipres_R_output_regression_punctuation_asymptote_lambda1.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_as)
cat("\n")
sum_as$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Test for punctuation (downturn) ----
pgls_dw <- gls(
  path ~ node + node2,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_dw <- summary(pgls_dw)
res_raw <- as.numeric(pgls_dw$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_dw$sigma^2
sink("surya_cipres_R_output_regression_punctuation_downturn_lambda1.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_dw)
cat("\n")
sum_dw$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()
