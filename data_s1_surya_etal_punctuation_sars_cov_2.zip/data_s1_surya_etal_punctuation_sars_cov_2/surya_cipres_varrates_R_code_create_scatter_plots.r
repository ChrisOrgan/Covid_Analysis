# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)  # v1.5.12
library(ggplot2)  # v3.3.0
library(ggthemes)  # v4.2.0
library(svglite)  # v1.2.3


# Load and prepare data ----
dat <- read.table(
  "surya_cipres_varrates_R_data_path_lengths_nodes.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path_mol", "path_time", "node")

# Create scatter plot
plot_reg <-
  ggplot(dat, aes(path_time, path_mol, color = node)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$path_time),
      xend = max(dat$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat$path_time) + 
          0.00003659848*min(dat$node) +
          0.00000003375776*min(dat$path_time)*min(dat$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat$path_time) + 
             0.00003659848*max(dat$node) +
             0.00000003375776*max(dat$path_time)*max(dat$node),
      color = "black",
      size = 0.5
    ) +
    scale_colour_gradient(breaks = c(0, 2, 4, 6, 8, 10), low = "gray90", high = "gray30") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nTime path length (days)",
      y = "Total path length (mutations/site)\n",
      color = "Node count\n"
    )

# Save scatter plots ----
CairoPDF("surya_cipres_varrates_figure_regression_time_node_inter.pdf",
         width = 4.75, height = 2.94)
print(plot_reg)
graphics.off()
CairoSVG("surya_cipres_varrates_figure_regression_time_node_inter.svg",
         width = 4.75, height = 2.94)
print(plot_reg)
graphics.off()
