# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)  # v1.5.12
library(ggplot2)  # v3.3.0
library(ggthemes)  # v4.2.0
library(htmlwidgets)  # v1.5.1
library(plotly)  # v4.9.2.1
library(svglite)  # v1.2.3


# Load and prepare data ----
dat <- read.table(
  "surya_cipres_varrates_R_data_path_lengths_nodes.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path_mol", "path_time", "node")
dat_node_01 <- dat[dat$node == 0 | dat$node == 1, ]
dat_node_2 <- dat[dat$node == 2, ]
dat_node_3 <- dat[dat$node == 3, ]
dat_node_4 <- dat[dat$node == 4, ]
dat_node_5 <- dat[dat$node == 5, ]
dat_node_6 <- dat[dat$node == 6, ]
dat_node_7 <- dat[dat$node == 7, ]
dat_node_8 <- dat[dat$node == 8, ]
dat_node_9 <- dat[dat$node == 9, ]
dat_node_10 <- dat[dat$node == 10, ]
dat_time_50 <- dat[dat$path_time <= 50, ]
dat_time_100 <- dat[dat$path_time > 50 & dat$path_time <= 100, ]
dat_time_150 <- dat[dat$path_time > 100 & dat$path_time <= 150, ]
dat_time_150p <- dat[dat$path_time > 150, ]

# Create scatter plot ----
plot_reg <-
  ggplot(dat, aes(path_time, path_mol, color = node)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$path_time),
      xend = max(dat$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat$path_time) + 
          0.00003659848*min(dat$node) +
          0.00000003375776*min(dat$path_time)*min(dat$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat$path_time) + 
             0.00003659848*max(dat$node) +
             0.00000003375776*max(dat$path_time)*max(dat$node),
      color = "black",
      size = 0.5
    ) +
    scale_colour_gradient(
      breaks = c(0, 2, 4, 6, 8, 10),
      low = "gray90",
      high = "gray30"
    ) +
    guides(colour = guide_colourbar(barwidth = 0.25, ticks = FALSE)) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nTime path length (days)",
      y = "Total path length (mutations/site)\n",
      color = "Node count\n"
    )
plot_effect_rate <-
  ggplot(dat, aes(path_time, path_mol)) +
    geom_point(size = 0.5, color = "gray92") +
    geom_segment(
      x = min(dat_node_01$path_time),
      xend = max(dat_node_01$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_01$path_time) + 
          0.00003659848*min(dat_node_01$node) +
          0.00000003375776*min(dat_node_01$path_time)*min(dat_node_01$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_01$path_time) + 
             0.00003659848*max(dat_node_01$node) +
             0.00000003375776*max(dat_node_01$path_time)*max(dat_node_01$node),
      color = "gray0",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_01$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_01$path_time) + 
          0.00003659848*min(dat_node_01$node) +
          0.00000003375776*min(dat_node_01$path_time)*min(dat_node_01$node),
      label = "0-1",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_2$path_time),
      xend = max(dat_node_2$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_2$path_time) + 
          0.00003659848*min(dat_node_2$node) +
          0.00000003375776*min(dat_node_2$path_time)*min(dat_node_2$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_2$path_time) + 
             0.00003659848*max(dat_node_2$node) +
             0.00000003375776*max(dat_node_2$path_time)*max(dat_node_2$node),
      color = "gray5",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_2$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_2$path_time) + 
          0.00003659848*min(dat_node_2$node) +
          0.00000003375776*min(dat_node_2$path_time)*min(dat_node_2$node),
      label = "2",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_3$path_time),
      xend = max(dat_node_3$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_3$path_time) + 
          0.00003659848*min(dat_node_3$node) +
          0.00000003375776*min(dat_node_3$path_time)*min(dat_node_3$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_3$path_time) + 
             0.00003659848*max(dat_node_3$node) +
             0.00000003375776*max(dat_node_3$path_time)*max(dat_node_3$node),
      color = "gray15",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_3$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_3$path_time) + 
          0.00003659848*min(dat_node_3$node) +
          0.00000003375776*min(dat_node_3$path_time)*min(dat_node_3$node),
      label = "3",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_4$path_time),
      xend = max(dat_node_4$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_4$path_time) + 
          0.00003659848*min(dat_node_4$node) +
          0.00000003375776*min(dat_node_4$path_time)*min(dat_node_4$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_4$path_time) + 
             0.00003659848*max(dat_node_4$node) +
             0.00000003375776*max(dat_node_4$path_time)*max(dat_node_4$node),
      color = "gray25",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_4$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_4$path_time) + 
          0.00003659848*min(dat_node_4$node) +
          0.00000003375776*min(dat_node_4$path_time)*min(dat_node_4$node),
      label = "4",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_5$path_time),
      xend = max(dat_node_5$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_5$path_time) + 
          0.00003659848*min(dat_node_5$node) +
          0.00000003375776*min(dat_node_5$path_time)*min(dat_node_5$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_5$path_time) + 
             0.00003659848*max(dat_node_5$node) +
             0.00000003375776*max(dat_node_5$path_time)*max(dat_node_5$node),
      color = "gray35",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_5$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_5$path_time) + 
          0.00003659848*min(dat_node_5$node) +
          0.00000003375776*min(dat_node_5$path_time)*min(dat_node_5$node),
      label = "5",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_6$path_time),
      xend = max(dat_node_6$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_6$path_time) + 
          0.00003659848*min(dat_node_6$node) +
          0.00000003375776*min(dat_node_6$path_time)*min(dat_node_6$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_6$path_time) + 
             0.00003659848*max(dat_node_6$node) +
             0.00000003375776*max(dat_node_6$path_time)*max(dat_node_6$node),
      color = "gray45",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_6$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_6$path_time) + 
          0.00003659848*min(dat_node_6$node) +
          0.00000003375776*min(dat_node_6$path_time)*min(dat_node_6$node),
      label = "6",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_7$path_time),
      xend = max(dat_node_7$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_7$path_time) + 
          0.00003659848*min(dat_node_7$node) +
          0.00000003375776*min(dat_node_7$path_time)*min(dat_node_7$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_7$path_time) + 
             0.00003659848*max(dat_node_7$node) +
             0.00000003375776*max(dat_node_7$path_time)*max(dat_node_7$node),
      color = "gray55",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_7$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_7$path_time) + 
          0.00003659848*min(dat_node_7$node) +
          0.00000003375776*min(dat_node_7$path_time)*min(dat_node_7$node),
      label = "7",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_8$path_time),
      xend = max(dat_node_8$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_8$path_time) + 
          0.00003659848*min(dat_node_8$node) +
          0.00000003375776*min(dat_node_8$path_time)*min(dat_node_8$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_8$path_time) + 
             0.00003659848*max(dat_node_8$node) +
             0.00000003375776*max(dat_node_8$path_time)*max(dat_node_8$node),
      color = "gray65",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_8$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_8$path_time) + 
          0.00003659848*min(dat_node_8$node) +
          0.00000003375776*min(dat_node_8$path_time)*min(dat_node_8$node),
      label = "8",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_9$path_time),
      xend = max(dat_node_9$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_9$path_time) + 
          0.00003659848*min(dat_node_9$node) +
          0.00000003375776*min(dat_node_9$path_time)*min(dat_node_9$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_9$path_time) + 
             0.00003659848*max(dat_node_9$node) +
             0.00000003375776*max(dat_node_9$path_time)*max(dat_node_9$node),
      color = "gray75",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_9$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_9$path_time) + 
          0.00003659848*min(dat_node_9$node) +
          0.00000003375776*min(dat_node_9$path_time)*min(dat_node_9$node),
      label = "9",
      size = 2.5,
      family = "Arial"
    ) +
    geom_segment(
      x = min(dat_node_10$path_time),
      xend = max(dat_node_10$path_time),
      y = -0.00002616336 + -0.00000009657477*min(dat_node_10$path_time) + 
          0.00003659848*min(dat_node_10$node) +
          0.00000003375776*min(dat_node_10$path_time)*min(dat_node_10$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_node_10$path_time) + 
             0.00003659848*max(dat_node_10$node) +
             0.00000003375776*max(dat_node_10$path_time)*max(dat_node_10$node),
      color = "gray80",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    annotate(
      "text",
      x = min(dat_node_10$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_10$path_time) + 
          0.00003659848*min(dat_node_10$node) +
          0.00000003375776*min(dat_node_10$path_time)*min(dat_node_10$node),
      label = "10",
      size = 2.5,
      family = "Arial"
    ) +
    annotate(
      "text",
      x = min(dat_node_10$path_time) - 5,
      y = -0.00002616336 + -0.00000009657477*min(dat_node_10$path_time) + 
          0.00003659848*min(dat_node_10$node) +
          0.00000003375776*min(dat_node_10$path_time)*min(dat_node_10$node) +
          0.75e-04,
      label = "Node count",
      size = 3,
      family = "Arial"
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nTime path length (days)",
      y = "Total path length (mutations/site)\n",
      color = "Node count\n"
    )
plot_effect_node <-
  ggplot(dat, aes(node, path_mol)) +
    geom_point(size = 0.5, color = "gray92") +
    geom_segment(
      x = min(dat_time_50$node),
      xend = max(dat_time_50$node),
      y = -0.00002616336 + -0.00000009657477*min(dat_time_50$path_time) + 
          0.00003659848*min(dat_time_50$node) +
          0.00000003375776*min(dat_time_50$path_time)*min(dat_time_50$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_time_50$path_time) + 
             0.00003659848*max(dat_time_50$node) +
             0.00000003375776*max(dat_time_50$path_time)*max(dat_time_50$node),
      color = "gray0",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    geom_segment(
      x = min(dat_time_100$node),
      xend = max(dat_time_100$node),
      y = -0.00002616336 + -0.00000009657477*min(dat_time_100$path_time) + 
          0.00003659848*min(dat_time_100$node) +
          0.00000003375776*min(dat_time_100$path_time)*min(dat_time_100$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_time_100$path_time) + 
             0.00003659848*max(dat_time_100$node) +
             0.00000003375776*max(dat_time_100$path_time)*max(dat_time_100$node),
      color = "gray25",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    geom_segment(
      x = min(dat_time_150$node),
      xend = max(dat_time_150$node),
      y = -0.00002616336 + -0.00000009657477*min(dat_time_150$path_time) + 
          0.00003659848*min(dat_time_150$node) +
          0.00000003375776*min(dat_time_150$path_time)*min(dat_time_150$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_time_150$path_time) + 
             0.00003659848*max(dat_time_150$node) +
             0.00000003375776*max(dat_time_150$path_time)*max(dat_time_150$node),
      color = "gray50",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    geom_segment(
      x = min(dat_time_150p$node),
      xend = max(dat_time_150p$node),
      y = -0.00002616336 + -0.00000009657477*min(dat_time_150p$path_time) + 
          0.00003659848*min(dat_time_150p$node) +
          0.00000003375776*min(dat_time_150p$path_time)*min(dat_time_150p$node),
      yend = -0.00002616336 + -0.00000009657477*max(dat_time_150p$path_time) + 
             0.00003659848*max(dat_time_150p$node) +
             0.00000003375776*max(dat_time_150p$path_time)*max(dat_time_150p$node),
      color = "gray75",
      size = 0.5,
      inherit.aes = FALSE
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations/site)\n"
    )

# Create a 3D scatter plot ----
plot3d <- plot_ly(
  data = dat,
  x = ~node,
  y = ~path_time,
  z = ~path_mol,
  color = ~node,
  size = 1.25
)
plot3d <- plot3d %>% add_markers()
plot3d <- plot3d %>% layout(
  scene = list(
    xaxis = list(title = "Node count"),
    yaxis = list(title = "Time path length (days)"),
    zaxis = list(title = "Molecular path length (subs/site)")
  )
)

# Save scatter plots ----
CairoPDF("surya_cipres_varrates_figure_regression_time_node_inter.pdf",
         width = 4.75, height = 2.94)
print(plot_reg)
graphics.off()
CairoSVG("surya_cipres_varrates_figure_regression_time_node_inter.svg",
         width = 4.75, height = 2.94)
print(plot_reg)
graphics.off()
CairoPDF("surya_cipres_varrates_figure_regression_time_node_inter_effect.pdf",
         width = 4.75, height = 2.94)
print(plot_effect_rate)
graphics.off()
CairoPDF("surya_cipres_varrates_figure_regression_time_node_inter_effect_node.pdf",
         width = 4.75, height = 2.94)
print(plot_effect_node)
graphics.off()
saveWidget(
  widget = as_widget(plot3d),
  file = "surya_cipres_varrates_figure_regression_time_node_inter_effect.html"
)
