#!/bin/bash

# Setup Bash Linux ----
sudo apt update  # gets the latest list of packages in the repositories
sudo apt upgrade -y  # upgrades all installed packages to their latest versions

# Install curl, and git ----
sudo apt-get install curl
sudo apt-get install git

# Install compilers of C and C++ programs under WSL with GCC ----
sudo apt install build-essential -y
sudo apt-get install autoconf automake make gcc perl zlib1g-dev libbz2-dev
sudo apt-get install liblzma-dev libcurl4-gnutls-dev libssl-dev

# Install ZSH and Oh My Zsh ----
sudo apt-get install zsh -y
sudo chsh -s $(which zsh)
curl -L https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh | bash
git clone https://github.com/zsh-users/zsh-syntax-highlighting.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting
git clone https://github.com/zsh-users/zsh-autosuggestions.git ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions

# Prepends text to file ----
sed -i '1i export PATH=$HOME/bin:/usr/local/bin:$PATH' ~/.zshrc
echo 'plugins=(git zsh-autosuggestions zsh-syntax-highlighting)' >> ~/.zshrc
echo 'ZSH_DISABLE_COMPFIX="true"' >> ~/.zshrc
sed -i '1i if test -t 1; then exec zsh; fi' ~/.bashrc

# Set up Miniconda ----
mkdir -p ~/miniconda3
wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh -O ~/miniconda3/miniconda.sh
bash ~/miniconda3/miniconda.sh -b -u -p ~/miniconda3
rm -rf ~/miniconda3/miniconda.sh
~/miniconda3/bin/conda init bash
~/miniconda3/bin/conda init zsh

# Restart shell and configure ----
source .bashrc
