# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(Cairo)
library(ggimage)
library(ggtree)
library(phytools)
library(svglite)


# Load tree ----
tree <- read.nexus(file = "lanfear_2021_tree_collapsed.nex")

# Randomly select 10,000 sequences ----
keep_seq <- sample(tree$tip.label, size = 10000)
tree_edit <- keep.tip(phy = tree, tip = keep_seq)

# Plot tree ----
plot_tree_edit <-
  ggtree(tree_edit, size = 0.1) +
    theme_tree2() +
    labs(caption = "mutations/site")

# Save tree plot ----
CairoPDF("surya_lanfear_2021_collapsed_figure_tree.pdf", width = 4.75,
         height = 6)
print(plot_tree_edit)
graphics.off()
CairoSVG("surya_lanfear_2021_collapsed_figure_tree.svg", width = 4.75,
         height = 6)
print(plot_tree_edit)
graphics.off()
