# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(LaplacesDemon)


# Load and prepare data ----
setwd("subsampling_lanfear_2021_collapsed_1000")
slope <- read.table(
  "surya_lanfear_2021_collapsed_R_output_subsampling_beta1.txt"
)
r2 <- read.table("surya_lanfear_2021_collapsed_R_output_subsampling_r2.txt")
setwd("..")
slope$iteration <- r2$iteration <- 1:1000
colnames(slope)[1] <- "slopes"
colnames(r2)[1] <- "r2"

# Determine modes ----
modes_slope <- Modes(slope$slopes)
# modes_slope
## $modes
## [1] 6.207052e-05 4.044906e-06 4.556949e-05
## 
## $mode.dens
## [1] 50261.62 19995.89 15747.77
## 
## $size
## [1] 0.6536452 0.1756786 0.1706763
## 
