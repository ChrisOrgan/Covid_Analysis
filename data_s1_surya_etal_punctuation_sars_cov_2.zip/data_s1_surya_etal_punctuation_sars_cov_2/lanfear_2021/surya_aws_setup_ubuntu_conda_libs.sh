#!/bin/bash

# Install Conda libraries ----
conda config --add channels bioconda
conda config --add channels conda-forge
conda config --add channels r
conda config --set channel_priority false
conda install r-essentials -y
conda install -c r r-ape r-nlme r-phytools -y
