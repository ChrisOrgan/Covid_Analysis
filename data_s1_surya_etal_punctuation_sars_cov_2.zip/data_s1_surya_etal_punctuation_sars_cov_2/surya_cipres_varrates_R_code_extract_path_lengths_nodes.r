# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)  # v5.3
library(phytools)  # v0.7.20
library(stringr)  # v.1.4.0


# Read trees ----
tree_mol <- read.nexus(file = "surya_cipres_tree_collapsed_v4.nex")
tree_time <- read.nexus(file = "surya_cipres_time_tree_collapsed.nex")

# Decompose trees into variance-covariance matrices ----
vcv_mol <- vcv(phy = tree_mol)
vcv_time <- vcv(phy = tree_time)

# Extract path lengths (diagonals of the matrix) ----
path_mol <- diag(vcv_mol)
path_time <- diag(vcv_time)

# Extract nodes ----
node_mol <- NULL
for (taxon in 1:length(tree_mol$tip.label)) {
  node_mol[taxon] <- length(
    nodepath(
      phy = tree_mol,
      from = length(tree_mol$tip.label) + 1,  # root
      to = taxon
    )
  ) - 2  # minus the root and terminal tip
}
node_time <- NULL
for (taxon in 1:length(tree_time$tip.label)) {
  node_time[taxon] <- length(
    nodepath(
      phy = tree_time,
      from = length(tree_mol$tip.label) + 1,
      to = taxon
    )
  ) - 2
}

# Create data frames ----
dat_mol <- data.frame(tree_mol$tip.label, path_mol, node_mol)
dat_time <- data.frame(tree_time$tip.label, path_time, node_time)
colnames(dat_mol) <- colnames(dat_time) <- c("taxon", "path", "node")
rownames(dat_mol) <- rownames(dat_time) <- NULL
dat_time <- dat_time[match(dat_mol$taxon, dat_time$taxon), ]
## length((dat_mol$node == dat_time$node) == TRUE)
### [1] 15019
dat <- data.frame(dat_mol$taxon, dat_mol$path, dat_time$path, dat_mol$node)
colnames(dat) <- c("taxon", "path_mol", "path_time", "node")

# Write data frames to tab-delimited text files ----
write.table(
  dat,
  file = "surya_cipres_varrates_R_data_path_lengths_nodes.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
