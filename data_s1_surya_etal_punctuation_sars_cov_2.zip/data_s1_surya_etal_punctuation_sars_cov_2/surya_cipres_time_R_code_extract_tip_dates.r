# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)  # v5.3
library(phytools)  # v0.7.20
library(stringr)  # v.1.4.0


# Read tree ----
tree <- read.nexus(file = "surya_cipres_tree_collapsed.nex")
tree_edit <- read.nexus(file = "surya_cipres_tree_collapsed_v2.nex")

# Extract tip dates (collection dates) ----
tip_temp <- word(tree$tip.label, start = 3, end = 3, sep = "\\|")
tip_temp <- gsub("-3-", "-03-", tip_temp)  # Fix the month formatting
tip_temp <- gsub("-4-", "-04-", tip_temp)
## length(tip_temp[nchar(tip_temp) == 10])
## [1] 15019
tip_temp <- gsub("-00", "-01", tip_temp)  # Fix the day formatting
tip <- data.frame(tree_edit$tip.label, tip_temp)

# Write tip dates to a tab-delimited text file ----
write.table(
  tip,
  file = "surya_cipres_time_R_data_tip_dates.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
