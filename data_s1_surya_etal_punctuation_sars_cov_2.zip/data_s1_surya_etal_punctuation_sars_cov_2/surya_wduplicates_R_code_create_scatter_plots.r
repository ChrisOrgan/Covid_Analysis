# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.
# Part of the codes were adopted from Kamil Slowikowski.
# See https://slowkow.com/notes/ggplot2-color-by-density/


library(Cairo)  # v1.5.12
library(ggplot2)  # v3.3.0
library(ggthemes)  # v4.2.0
library(htmlwidgets)  # v1.5.1
library(MASS)  # v7.3.51.5
library(plotly)  # v4.9.2.1
library(svglite)  # v1.2.3


# Load and prepare data ----
dat <- read.table(
  "surya_wduplicates_R_data_path_lengths_nodes_region.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path", "node", "continent")
dat_out <- read.table("surya_wduplicates_R_output_outliers.txt")
colnames(dat_out) <- c("outlier")
dat_edit <- dat[!dat$genome %in% as.character(dat_out$outlier), ]

# Plot scatter plots ----
# Get density of points in 2 dimensions.
# @param x A numeric vector.
# @param y A numeric vector.
# @param n Create a square n by n grid to compute density.
# @return The density within each square.
get_density <- function(x, y, ...) {
  dens <- MASS::kde2d(x, y, ...)
  ix <- findInterval(x, dens$x)
  iy <- findInterval(y, dens$y)
  ii <- cbind(ix, iy)
  return(dens$z[ii])
}
dat$density <- get_density(dat$node, dat$path, n = 3000)
plot_reg <-
  ggplot(dat, aes(node, path, color = density)) +
    geom_point(size = 0.75) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.0000005895564 + 0.0000008291602*min(dat$node),
      yend = 0.0000005895564 + 0.0000008291602*max(dat$node),
      color = "black",
      size = 0.5
    ) +
    scale_colour_gradient(low = "gray90", high = "gray10") +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "right") +
    labs(
      x = "\nNode count",
      y = "Total path length (mutations/site)\n",
      color = "Density\n"
    )
plot_reg_out <-
  ggplot(dat_edit, aes(node, path)) +
    geom_point(color = "gray") +
    geom_segment(
      x = min(dat_edit$node),
      xend = max(dat_edit$node),
      y = 0.0000005898981 + 0.0000008288184*min(dat_edit$node),
      yend = 0.0000005898981 + 0.0000008288184*max(dat_edit$node),
      color = "black",
      size = 1
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length (mutations/site)\n")
plot_reg_out_alpha <-
  ggplot(dat_edit, aes(node, path)) +
    geom_point(color = "gray", alpha = 0.25) +
    geom_segment(
      x = min(dat_edit$node),
      xend = max(dat_edit$node),
      y = 0.0000005898981 + 0.0000008288184*min(dat_edit$node),
      yend = 0.0000005898981 + 0.0000008288184*max(dat_edit$node),
      color = "black",
      size = 1
    ) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length (mutations/site)\n")
## Interactive plots
plot_interactive <-
  ggplot(dat, aes(node, path, color = continent, label = genome)) +
    geom_point(alpha = 0.4) +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    theme(legend.title = element_blank()) +
    labs(
      x = "Node count",
      y = "Total path length (mutations/site)"
    )
plot_interactive <- ggplotly(plot_interactive)

# Save scatter plots ----
CairoPDF("surya_wduplicates_figure_punctuation.pdf", width = 5,
         height = 2.94)
print(plot_reg)
graphics.off()
CairoSVG("surya_wduplicates_figure_punctuation.svg", width = 5,
         height = 2.94)
print(plot_reg)
graphics.off()
CairoPDF("surya_wduplicates_figure_punctuation_no_outliers.pdf", width = 6.535,
         height = 4.039)
print(plot_reg_out)
graphics.off()
CairoSVG("surya_wduplicates_figure_punctuation_no_outliers.svg", width = 6.535,
         height = 4.039)
print(plot_reg_out)
graphics.off()
CairoPDF("surya_wduplicates_figure_punctuation_no_outliers_alpha.pdf",
         width = 6.535, height = 4.039)
print(plot_reg_out_alpha)
graphics.off()
CairoSVG("surya_wduplicates_figure_punctuation_no_outliers_alpha.svg",
         width = 6.535, height = 4.039)
print(plot_reg_out_alpha)
graphics.off()
## Interactive plots
saveWidget(
  widget = as_widget(plot_interactive),
  file = "surya_wduplicates_figure_punctuation_interactive.html"
)

# Should we need to plot 95% CIs, see:
# http://www.real-statistics.com/regression/confidence-and-prediction-intervals/
# https://statscalculator.com/tcriticalvaluecalculator?x1=0.05&x2=3958
