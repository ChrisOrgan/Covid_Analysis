# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)  # v5.3
library(phytools)  # v0.7.20


# Read tree ----
tree <- read.nexus(file = "surya_cipres_tree_collapsed.nex")

# Edit tree tip labels ----
seq_names <- read.table("surya_R_output_sequence_names.txt", sep = "\t")
colnames(seq_names) <- c("original", "edited")
seq_names <- seq_names[match(tree$tip.label, seq_names$original), ]
tree$tip.label <- seq_names$edited

# Force tree to be treated as rooted ----
tree$root.edge <- 0

# Write tree ----
writeNexus(tree = tree, file = "surya_cipres_tree_collapsed_v2.nex")
write.tree(phy = tree, file = "surya_cipres_tree_collapsed_v3.nwk")
