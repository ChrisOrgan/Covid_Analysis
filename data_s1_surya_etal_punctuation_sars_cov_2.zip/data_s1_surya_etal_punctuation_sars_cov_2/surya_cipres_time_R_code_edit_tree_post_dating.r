# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)  # v5.3
library(phytools)  # v0.7.20


# Read and prepare trees ----
tree_mol <- read.nexus(file = "surya_cipres_tree_collapsed.nex")
tree_mol <- root(
  phy = tree_mol,
  outgroup = "hCoV-19/Wuhan/WIV04/2019|EPI_ISL_402124|2019-12-30|China",
  resolve.root = TRUE
)
tree_time <- read.nexus(file = "lsd2/surya_cipres_time_R_output.date.nexus")
seq_names <- read.table("surya_R_output_sequence_names.txt", sep = "\t")
colnames(seq_names) <- c("original", "edited")
seq_names <- seq_names[match(tree_time$tip.label, seq_names$edited), ]
tree_time$tip.label <- seq_names$original
tree_time$edge.length <- tree_time$edge.length * 365  # branch length unit: day

# Check if the tree topologies remain unchanged ----
all.equal.phylo(target = tree_mol, current = tree_time, use.edge.length = FALSE)
## [1] TRUE

# Write tree ----
writeNexus(tree = tree_mol, file = "surya_cipres_tree_collapsed_v4.nex")
writeNexus(tree = tree_time, file = "surya_cipres_time_tree_collapsed.nex")
