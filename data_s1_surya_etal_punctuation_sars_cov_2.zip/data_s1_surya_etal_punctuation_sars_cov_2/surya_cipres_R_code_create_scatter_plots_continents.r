# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)  # v1.5.12
library(ggplot2)  # v3.3.0
library(ggthemes)  # v4.2.0


# Load and prepare data ----
dat <- read.table(
  "surya_cipres_R_data_path_lengths_nodes_region.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path", "node", "continent")
dat_africa <- dat[dat$continent == "Africa", ]
dat_asia <- dat[dat$continent == "Asia", ]
dat_europe <- dat[dat$continent == "Europe", ]
dat_namerica <- dat[dat$continent == "North America", ]
dat_oceania <- dat[dat$continent == "Oceania", ]
dat_samerica <- dat[dat$continent == "South America", ]

# Plot scatter plots ----
plot_reg_africa <-
  ggplot(dat_africa, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#F8766D") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_africa$node),
      xend = max(dat_africa$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_africa$node) +
          5.242879e-16*1340598113 +
          -1.641526e-16*min(dat_africa$node)*1340598113,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_africa$node) +
             5.242879e-16*1340598113 +
             -1.641526e-16*max(dat_africa$node)*1340598113,
      color = "#F8766D",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")
plot_reg_asia <-
  ggplot(dat_asia, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#B79F00") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_asia$node),
      xend = max(dat_asia$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_asia$node) +
          5.242879e-16*4641054786 +
          -1.641526e-16*min(dat_asia$node)*4641054786,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_asia$node) +
             5.242879e-16*4641054786 +
             -1.641526e-16*max(dat_asia$node)*4641054786,
      color = "#B79F00",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")
plot_reg_europe <-
  ggplot(dat_europe, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#00BA38") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_europe$node),
      xend = max(dat_europe$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_europe$node) +
          5.242879e-16*747636045 +
          -1.641526e-16*min(dat_europe$node)*747636045,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_europe$node) +
             5.242879e-16*747636045 +
             -1.641526e-16*max(dat_europe$node)*747636045,
      color = "#00BA38",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")
plot_reg_namerica <-
  ggplot(dat_namerica, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#00BFC4") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_namerica$node),
      xend = max(dat_namerica$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_namerica$node) +
          5.242879e-16*368092846 +
          -1.641526e-16*min(dat_namerica$node)*368092846,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_namerica$node) +
             5.242879e-16*368092846 +
             -1.641526e-16*max(dat_namerica$node)*368092846,
      color = "#00BFC4",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")
plot_reg_oceania <-
  ggplot(dat_oceania, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#619CFF") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_oceania$node),
      xend = max(dat_oceania$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_oceania$node) +
          5.242879e-16*42677809 +
          -1.641526e-16*min(dat_oceania$node)*42677809,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_oceania$node) +
             5.242879e-16*42677809 +
             -1.641526e-16*max(dat_oceania$node)*42677809,
      color = "#619CFF",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")
plot_reg_samerica <-
  ggplot(dat_samerica, aes(node, path)) +
    coord_cartesian(
      xlim = c(min(dat$node), max(dat$node)),
      ylim = c(min(dat$path), max(dat$path))
    ) +
    geom_point(size = 0.15, color = "#F564E3") +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.000002596172 + 0.00004221837*min(dat$node),
      yend = 0.000002596172 + 0.00004221837*max(dat$node),
      color = "gainsboro",
      size = 0.15
    ) +
    geom_segment(
      x = min(dat_samerica$node),
      xend = max(dat_samerica$node),
      y = 1.918459e-06 +
          4.237164e-05*min(dat_samerica$node) +
          5.242879e-16*653739130 +
          -1.641526e-16*min(dat_samerica$node)*653739130,
      yend = 1.918459e-06 +
             4.237164e-05*max(dat_samerica$node) +
             5.242879e-16*653739130 +
             -1.641526e-16*max(dat_samerica$node)*653739130,
      color = "#F564E3",
      size = 0.3
    ) +
    scale_x_continuous(breaks = c(0, 2, 4, 6, 8)) +
    theme_tufte(base_size = 7, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nNode count", y = "Total path length\n")

# Save scatter plots ----
CairoPDF("surya_cipres_figure_punctuation_con_africa.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_africa)
graphics.off()
CairoPDF("surya_cipres_figure_punctuation_con_asia.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_asia)
graphics.off()
CairoPDF("surya_cipres_figure_punctuation_con_europe.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_europe)
graphics.off()
CairoPDF("surya_cipres_figure_punctuation_con_namerica.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_namerica)
graphics.off()
CairoPDF("surya_cipres_figure_punctuation_con_oceania.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_oceania)
graphics.off()
CairoPDF("surya_cipres_figure_punctuation_con_samerica.pdf", width = 2.375,
         height = 1.5)
print(plot_reg_samerica)
graphics.off()
