# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(ape)
library(stringr)


# 1. We download from NCBI Virus 310 SARSr-CoV genomes (nucleotide).
#   - Virus: Severe acute respiratory syndrome-related coronavirus,
#            taxid:694009
#   - Sequence Type: GenBank
#   - Nucleotide Completeness: complete
#   - Release Date: From Apr 14, 2003 To Dec 31, 2018  # before COVID-19

# 2. Extract SARS-CoV-1 genomes based on Shang et al. (2006) ----
meta <- read.csv("ncbi_virus_sarsr_cov_metadata.csv", header = TRUE)
shang_list <- read.table(
  "2006_shang_etal_list_sars_cov_1_genomes.txt", sep = "\t"
)
colnames(shang_list) <- c("strain", "accession")
meta <- meta[meta$Accession %in% shang_list$accession, ]
## length(meta$Accession)  # < length(shang_list$accession)
dropped <- shang_list[!shang_list$accession %in% meta$Accession, ]
dropped  # incomplete genomes
##     strain accession
## 101    TWY  AP006561
## 102    TWS  AP006560
## 103    TWK  AP006559
## 104    TWJ  AP006558
## 105    TWH  AP006557

# 3. Remove non-human SARS-CoV-1 genomes, except the two from civets
#    (SZ3 and SZ16) ----
host_non_human <- as.character(unique(meta$Host))[c(2:3)]
## host_non_human
## [1] "Paradoxurus hermaphroditus" "Paguma larvata"
meta <- meta[!meta$Host %in% host_non_human, ]

# 4. Subset FASTA file ----
seq_sarsr_cov <- read.FASTA("ncbi_virus_sarsr_cov_seq.fasta")
seq_names <- names(seq_sarsr_cov)
seq_names <- word(seq_names, start = 1, end = 1, sep = " \\|")
seq_names <- word(seq_names, start = 1, end = 1, sep = "\\.")
seq_sars_cov <- seq_sarsr_cov[seq_names %in% meta$Accession]

# 5. Write FASTA file ----
seq_names <- names(seq_sars_cov)
seq_names_1 <- word(seq_names, start = 1, end = 1, sep = " \\|")
seq_names_1 <- word(seq_names, start = 1, end = 1, sep = "\\.")
seq_names_2 <- word(seq_names, start = 2, end = 2, sep = " \\|")
seq_names_2 <- gsub(", complete genome", "", seq_names_2)
seq_names_2 <- gsub(" |/|-|#", "_", seq_names_2)
seq_names <- paste(seq_names_1, seq_names_2, sep = "_")
names(seq_sars_cov) <- seq_names
write.FASTA(seq_sars_cov, file = "surya_sars_cov_seq.fasta")
