# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(Cairo)
library(ggimage)
library(ggtree)
library(phytools)
library(svglite)


# Load and prepare data ----
tree <- read.nexus(file = "surya_collapsed_tree.nex")
dat <- read.table(
  "surya_collapsed_R_data_path_lengths_nodes_deletion.txt",
  sep = "\t"
)
del_yes <- as.character(dat$V1[dat$V4 == 1])
del_no <- as.character(dat$V1[dat$V4 == 0])
del <- list(del_yes, del_no)
names(del) <- c(">= 29 nt deletion", "< 29 nt deletion")

# Plot tree ----
tree_plot <- groupOTU(tree, del)
plot_tree <-
  ggtree(tree_plot, aes(color = group), size = 0.45) +
    theme_tree2(legend.position = "none") +
    labs(caption = "mutations/site")

# Save tree plot ----
CairoPDF("surya_collapsed_figure_tree.pdf", width = 4.75, height = 5)
print(plot_tree)
graphics.off()
CairoSVG("surya_collapsed_figure_tree.svg", width = 4.75, height = 5)
print(plot_tree)
graphics.off()
