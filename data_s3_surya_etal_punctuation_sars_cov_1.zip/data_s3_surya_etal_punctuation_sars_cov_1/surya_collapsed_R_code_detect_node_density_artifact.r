# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-macroevolution project.


library(ape)
library(Cairo)
library(ggplot2)
library(ggthemes)
library(nlme)
library(svglite)


# Read tree ----
tree <- read.nexus(file = "surya_collapsed_tree.nex")

# Define correlation matrix ----
corr <- corPagel(value = 1, phy = tree, fixed = TRUE)

# Define variance weights ----
w <- diag(vcv(tree))

# Load and prepare data ----
dat <- read.table("surya_collapsed_R_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
rownames(dat) <- dat$genome
dat$node <- dat$node + 1  # This addition prevents log-transforming zero
dat <- dat[match(tree$tip.label, rownames(dat)), ]

# Detect node-density artifact ----
pgls <- gls(
  log(node) ~ log(path),
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
beta <- exp(as.numeric(pgls$coefficients[1]))
delta <- as.numeric(pgls$coefficients[2])
sink("surya_collapsed_R_output_node_density_artifact.txt")
cat("=================\n")
cat("Node-Density Test\n")
cat("=================\n\n")
summary(pgls)
cat("\n")
cat(paste("Delta = ", delta, sep = ""))
cat("\n")
sink()

# Create scatter plots ----
plot_bias <-
  ggplot(dat, aes(path, node)) +
    geom_point(color = "gray", size = 0.5) +
    stat_function(
      color = "red",
      size = 1,
      fun = function(path){beta * path^delta}
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nTotal path length", y = "Node count\n")

# Save scatter plots ----
CairoPDF("surya_collapsed_figure_punctuation_node_density_artifact.pdf",
         width = 4.75, height = 2.94)
print(plot_bias)
graphics.off()
CairoSVG("surya_collapsed_figure_punctuation_node_density_artifact.svg",
         width = 4.75, height = 2.94)
print(plot_bias)
graphics.off()
