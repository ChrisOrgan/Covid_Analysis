# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.
# Part of the codes were adopted from Sandra L. Ament-Velásquez.
# See http://evoslav.blogspot.com/2015/01/how-to-collapse-unsupported-branches-of.html


# library(ape)
library(phytools)


# Read and prepare tree ----
setwd("cipres")
tree <- read.newick(file = "output.treefile")
setwd("..")
tree$root.edge <- 0
tree$node.label <- as.numeric(gsub("/", "", tree$node.label))
tree$node.label[1] <- 1
out <- c("AY304486_SARS_coronavirus_SZ3", "AY304488_SARS_coronavirus_SZ16")
tree_edit <- drop.tip(phy = tree, tip = out)
## tree_edit
## 
## Phylogenetic tree with 104 tips and 103 internal nodes.
## 
## Tip labels:
##         AY545914_SARS_coronavirus_isolate_HC_SZ_79_03, AY545915_SARS_coronavirus_isolate_HC_SZ_DM1_03, AY545916_SARS_coronavirus_isolate_HC_SZ_266_03, AY545918_SARS_coronavirus_isolate_HC_GZ_32_03, AY545919_SARS_coronavirus_isolate_CFB_SZ_94_03, AY568539_SARS_coronavirus_GZ0401, ...
## Node labels:
##         1, 1, 0.833, 1, 0.992, 1, ...
## 
## Rooted; includes branch lengths.

# Locate nodes with low support values (< 0.5) ----
bad_nodes <- which(as.numeric(tree_edit$node.label) < 0.5) +
             length(tree_edit$tip.label)

# Get the actual indexes of the nodes with low support ----
bad_node_indexes <- c()
for(node in bad_nodes) {
  bad_node_indexes <- c(bad_node_indexes, which(tree_edit$edge[, 2] == node))
}

# Make the branch length of the bad nodes = 0 ----
tree_edit$edge.length[bad_node_indexes] <- 0

# Convert the branches with length = 0 to polytomies ----
tree_poly <- di2multi(tree_edit)
tree_poly$node.label <- NULL
## tree_poly
## 
## Phylogenetic tree with 104 tips and 54 internal nodes.
## 
## Tip labels:
##         AY545914_SARS_coronavirus_isolate_HC_SZ_79_03, AY545915_SARS_coronavirus_isolate_HC_SZ_DM1_03, AY545916_SARS_coronavirus_isolate_HC_SZ_266_03, AY545918_SARS_coronavirus_isolate_HC_GZ_32_03, AY545919_SARS_coronavirus_isolate_CFB_SZ_94_03, AY568539_SARS_coronavirus_GZ0401, ...
## 
## Rooted; includes branch lengths.

# Write tree in the NEXUS format ----
writeNexus(tree = tree_poly, file = "surya_collapsed_tree.nex")
