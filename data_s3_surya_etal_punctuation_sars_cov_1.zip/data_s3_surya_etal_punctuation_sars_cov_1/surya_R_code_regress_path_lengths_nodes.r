# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(nlme)
library(phytools)


# Read and prepare tree ----
tree <- read.nexus(file = "surya_tree.nex")
removed <- c("AY394997_SARS_coronavirus_ZS_A",
             "AY394996_SARS_coronavirus_ZS_B",
             "AY395003_SARS_coronavirus_ZS_C")
tree <- drop.tip(phy = tree, tip = removed)

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Define correlation matrix ----
corr <- corPagel(value = 1, phy = tree, fixed = TRUE)

# Define variance weights ----
w <- diag(vcv)

# Load and prepare data ----
dat <- read.table("surya_R_data_path_lengths_nodes_deletion.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node", "orf8")
rownames(dat) <- dat$genome
dat$orf8[dat$orf8 == 0] <- "intact"
dat$orf8[dat$orf8 == 1] <- "truncated"
dat <- dat[!dat$genome %in% removed, ]
dat <- dat[match(tree$tip.label, dat$genome), ]

# Fit intercept-only model ----
pgls_int <- gls(
  path ~ 1,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_int <- summary(pgls_int)
mean_phylo <- as.numeric(pgls_int$coefficients[1])
sigma2 <- sum_int$sigma^2
sink("surya_R_output_regression_punctuation_intercept_lambda1.txt")
cat("=================================\n")
cat("Punctuation Test (Intercept-Only)\n")
cat("=================================\n\n")
summary(pgls_int)
cat("\n")
sum_int$tTable
cat("\n")
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Test for punctuation ----
pgls_pe <- gls(
  path ~ node,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_pe <- summary(pgls_pe)
res_raw <- as.numeric(pgls_pe$residuals)
res_null <- as.matrix(dat$path - mean_phylo)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_pe$sigma^2
sink("surya_R_output_regression_punctuation_lambda1.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
summary(pgls_pe)
cat("\n")
sum_pe$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Fit equal-slopes model ----
pgls_eq <- gls(
  path ~ node + orf8,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_eq <- summary(pgls_eq)
res_raw <- as.numeric(pgls_eq$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_eq$sigma^2
sink("surya_R_output_regression_punctuation_equal_slopes_lambda1.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
sum_eq
cat("\n")
sum_eq$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()

# Fit separate-slopes model ----
pgls_sep <- gls(
  path ~ node * orf8,
  data = dat,
  correlation = corr,
  weights = varFixed(~w),
  method = "ML"
)
sum_sep <- summary(pgls_sep)
res_raw <- as.numeric(pgls_sep$residuals)
sse <- as.numeric(t(res_raw) %*% solve(vcv, tol = 2e-18) %*% res_raw)
sst <- as.numeric(t(res_null) %*% solve(vcv, tol = 2e-18) %*% res_null)
r2 <- 1 - sse/sst
sigma2 <- sum_sep$sigma^2
sink("surya_R_output_regression_punctuation_separate_slopes_lambda1.txt")
cat("================\n")
cat("Punctuation Test\n")
cat("================\n\n")
sum_sep
cat("\n")
sum_sep$tTable
cat("\n")
cat(paste("R-squared = ", r2, "\n", sep = ""))
cat(paste("Variance = ", sigma2, sep = ""))
cat("\n")
sink()
