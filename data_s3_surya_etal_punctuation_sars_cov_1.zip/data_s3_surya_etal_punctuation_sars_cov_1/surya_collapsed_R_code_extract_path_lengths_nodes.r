# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


# library(ape)
library(phytools)


# Read tree ----
tree <- read.nexus(file = "surya_collapsed_tree.nex")

# Decompose tree into variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Extract path lengths (diagonals of the matrix) ----
path <- diag(vcv)

# Extract nodes ----
node <- NULL
for (genome in 1:length(tree$tip.label)) {
  node[genome] <- length(
    nodepath(
      phy = tree,
      from = length(tree$tip.label) + 1,  # root
      to = genome
    )
  ) - 2  # minus the root and terminal tip
}

# Read data regarding the presence/absence of the 29 nt deletion
del29 <- read.csv("surya_sars_cov_29del.csv", header = FALSE)
colnames(del29) <- c("seq_names", "del")
del29$del <- as.character(del29$del)
del29$del[del29$del == "T"] <- 0
del29$del[del29$del == "-"] <- 1
del29 <- del29[match(tree$tip.label, del29$seq_names), ]

# Create data frames ----
dat <- data.frame(tree$tip.label, path, node)
dat_del <- data.frame(tree$tip.label, path, node, del29$del)
dat_int <- data.frame(tree$tip.label, path)  # intercept-only

# Write data frames to tab-delimited text files ----
write.table(
  dat,
  file = "surya_collapsed_R_data_path_lengths_nodes.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
write.table(
  dat_del,
  file = "surya_collapsed_R_data_path_lengths_nodes_deletion.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
write.table(
  dat_int,
  file = "surya_collapsed_R_data_path_lengths.txt",
  quote = FALSE,
  sep = "\t",
  row.names = FALSE,
  col.names = FALSE
)
