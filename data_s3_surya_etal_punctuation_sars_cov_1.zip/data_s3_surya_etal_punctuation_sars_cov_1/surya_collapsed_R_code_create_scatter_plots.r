# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(Cairo)
library(ggplot2)
library(ggthemes)
library(svglite)


# Load and prepare data ----
dat <- read.table(
  "surya_collapsed_R_data_path_lengths_nodes_deletion.txt",
  sep = "\t"
)
colnames(dat) <- c("genome", "path", "node", "deletion")
removed <- c("AY394997_SARS_coronavirus_ZS_A",
             "AY394996_SARS_coronavirus_ZS_B",
             "AY395003_SARS_coronavirus_ZS_C")
dat <- dat[!dat$genome %in% removed, ]
dat_out <- read.table("surya_collapsed_R_output_outliers.txt")
colnames(dat_out) <- c("outlier")
outliers <- as.character(dat_out$outlier)
dat_out <- dat[!dat$genome %in% outliers, ]

# Plot scatter plots ----
plot_reg <-
  ggplot(dat, aes(node, path, color = deletion)) +
    ylim(min(dat$path), 0.00425) +
    geom_jitter(width = 0.1) +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.0009506887 + 0.00005876865*min(dat$node),
      yend = 0.0009506887 + 0.00005876865*max(dat$node),
      color = "dark gray",
      size = 0.5
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (mutations/site)\n")
plot_reg_out <-
  ggplot(dat_out, aes(node, path, color = deletion)) +
    geom_point() +
    geom_segment(
      x = min(dat$node),
      xend = max(dat$node),
      y = 0.0009587193 + 0.00005433943*min(dat$node),
      yend = 0.0009587193 + 0.00005433943*max(dat$node),
      color = "dark gray",
      size = 0.5
    ) +
    theme_tufte(base_size = 10, base_family = "Arial", ticks = FALSE) +
    theme(legend.position = "none") +
    labs(x = "\nNode count", y = "Total path length (mutations/site)\n")

# Save scatter plots ----
CairoPDF("surya_collapsed_figure_punctuation_sars_cov.pdf", width = 4.75,
         height = 4)
print(plot_reg)
graphics.off()
CairoSVG("surya_collapsed_figure_punctuation_sars_cov.svg", width = 4.75,
         height = 4)
print(plot_reg)
graphics.off()
CairoPDF("surya_collapsed_figure_punctuation_sars_cov_no_outliers.pdf",
         width = 4.75, height = 4)
print(plot_reg_out)
graphics.off()
CairoSVG("surya_collapsed_figure_punctuation_sars_cov_no_outliers.svg",
         width = 4.75, height = 4)
print(plot_reg_out)
graphics.off()
