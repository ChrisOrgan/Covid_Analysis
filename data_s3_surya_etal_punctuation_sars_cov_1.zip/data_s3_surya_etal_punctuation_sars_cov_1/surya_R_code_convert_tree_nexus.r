# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(phytools)


# Read and prepare tree ----
setwd("cipres")
tree <- read.newick(file = "output.treefile")
setwd("..")
tree$root.edge <- 0
tree$node.label <- NULL
out <- c("AY304486_SARS_coronavirus_SZ3", "AY304488_SARS_coronavirus_SZ16")
tree_edit <- drop.tip(phy = tree, tip = out)
## tree_edit
## 
## Phylogenetic tree with 104 tips and 103 internal nodes.
## 
## Tip labels:
##         AY545914_SARS_coronavirus_isolate_HC_SZ_79_03, AY545915_SARS_coronavirus_isolate_HC_SZ_DM1_03, AY545916_SARS_coronavirus_isolate_HC_SZ_266_03, AY545918_SARS_coronavirus_isolate_HC_GZ_32_03, AY545919_SARS_coronavirus_isolate_CFB_SZ_94_03, AY568539_SARS_coronavirus_GZ0401, ...
## 
## Rooted; includes branch lengths.

# Write tree in the NEXUS format ----
writeNexus(tree = tree_edit, file = "surya_tree.nex")
