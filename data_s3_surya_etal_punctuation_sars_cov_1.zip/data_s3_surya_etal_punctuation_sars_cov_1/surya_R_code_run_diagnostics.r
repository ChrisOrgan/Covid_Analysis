# Written by Kevin Surya, 2020.
# This code is part of the coronavirus-evolution project.


library(ape)
library(ggExtra)
library(ggplot2)
library(ggthemes)
library(svglite)


# Read and prepare tree ----
tree <- read.nexus(file = "surya_tree.nex")
removed <- c("AY394997_SARS_coronavirus_ZS_A",
             "AY394996_SARS_coronavirus_ZS_B",
             "AY395003_SARS_coronavirus_ZS_C")
tree <- drop.tip(phy = tree, tip = removed)

# Define variance-covariance matrix ----
vcv <- vcv(phy = tree)

# Write function `Dfun` ----
## See https://github.com/cran/caper/blob/master/R/pgls.R
Dfun <- function(Cmat) {
  iCmat <- solve(Cmat, tol = 2e-18)
  svdCmat <- La.svd(iCmat)
  D <- svdCmat$u %*% diag(sqrt(svdCmat$d)) %*% t(svdCmat$v)
  return(t(D))
}

# Load and prepare data ----
dat <- read.table("surya_R_data_path_lengths_nodes.txt", sep = "\t")
colnames(dat) <- c("genome", "path", "node")
dat <- dat[!dat$genome %in% removed, ]
dat$fitted_values <- 0.001107862 + 0.000005342017*dat$node
dat$res_raw <- dat$path - dat$fitted_values
dat$res_phy <- as.vector(Dfun(vcv) %*% dat$res_raw)

# Plot marginal histogram scatter plots of residuals ----
plot_diag <-
  ggplot(dat, aes(fitted_values, res_phy)) +
    geom_point(color = "gray", size = 0.5) +
    geom_smooth(
      color = "red",
      size = 1,
      method = "loess",
      se = FALSE
    ) +
    scale_y_reverse() +
    theme_tufte(base_size = 12, base_family = "Arial", ticks = FALSE) +
    labs(x = "\nFitted values", y = "Residuals\n")
plot_diag <- ggMarginal(plot_diag, type = "density", margins = "y", size = 1.75)

# Save diagnostic plots ----
ggsave("surya_figure_punctuation_diagnostics.pdf", width = 4.75, height = 3.81,
       device = cairo_pdf, plot_diag)
graphics.off()
ggsave("surya_figure_punctuation_diagnostics.svg", width = 4.75, height = 3.81,
       plot_diag)
graphics.off()
